    <footer class="main-footer">
        <!-- <strong>Copyright &copy; 2023 1184097.</strong>
        Andika Dwi Arko. -->
        <div class="float-right d-none d-sm-inline-block">
            <!-- CodeIgniter<b>Version</b> 4.1.4 -->
        </div>
    </footer>