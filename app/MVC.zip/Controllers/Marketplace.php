<?php

namespace App\Controllers;

use App\Models\TransaksiModel;
use App\Models\DataTransaksiModel;
use App\Models\MahasiswaModel;
use App\Models\QuisModel;

class Marketplace extends BaseController
{
    protected $TransaksiModel;
    protected $DataTransaksiModel;
    protected $MahasiswaModel;
    protected $QuisModel;

    public function __construct()
    {
        $this->TransaksiModel = new TransaksiModel();
        $this->DataTransaksiModel = new DataTransaksiModel();
        $this->MahasiswaModel = new MahasiswaModel();
        $this->QuisModel = new QuisModel();
    }

    public function toko()
    {
        $transaksi = $this->TransaksiModel->findAll(); // Pastikan model ini mengembalikan data yang sesuai

        $data = array(
            'title' => 'Market Place',
            'transaksi' => $transaksi,
        );
        return view('Marketplace/toko', $data);
    }

    public function edit()
    {
        $id_transaksi = $this->request->getPost('id_transaksi');
        $nama_transaksi = $this->request->getPost('nama_transaksi');
        $poin_digunakan = $this->request->getPost('poin_digunakan');
        $detail = $this->request->getPost('detail');

        // Lakukan validasi data jika diperlukan

        // Update data transaksi
        $data = [
            'nama_transaksi' => $nama_transaksi,
            'poin_digunakan' => $poin_digunakan,
            'detail' => $detail,
        ];

        $this->TransaksiModel->update($id_transaksi, $data);

        // Redirect atau tampilkan pesan sukses
        return redirect()->to('/toko')->with('sukses', 'Data transaksi berhasil diupdate');
    }

    public function market()
    {
        $session = session();
        // $isLoggedIn = $session->get('isLoggedIn'); // Ambil status login dari sesi
        $nama = $session->get('nama');
        $npm = $session->get('npm');
        // $mahasiswa = $this->MahasiswaModel->where('nama', $username)->first();

        // Mengambil total poin dari model Mahasiswa
        $mahasiswaData = $this->MahasiswaModel->getPointByNpm($npm);
        $totalPoints = $mahasiswaData['point'] ?? 0; // Menggunakan null coalescing operator untuk default 0
        // Memperbarui poin di session
        $session->set('point', $totalPoints);

        // Ambil semua transaksi yang tersedia
        $transaksi = $this->TransaksiModel->findAll(); // Pastikan model ini mengembalikan data yang sesuai
        $datatransaksi = $this->DataTransaksiModel->getRewardsByNpmAndValidation($npm, 'Sudah'); // Ambil reward yang sudah divalidasi

        $data = [
            'title' => 'MarketPlace',
            // 'isLoggedIn' => $isLoggedIn,
            'npm' => $npm,
            'nama' => $nama,
            // 'mahasiswa' => $mahasiswa,
            'point' => $totalPoints,
            'transaksi' => $transaksi,
            'datatransaksi' => $datatransaksi
        ];

        return view('Marketplace/marketplace', $data);
    }

    public function misi()
    {
        $session = session();
        // $isLoggedIn = $session->get('isLoggedIn'); // Ambil status login dari sesi
        $nama = $session->get('nama');
        $npm = $session->get('npm');
        // $mahasiswa = $this->MahasiswaModel->where('nama', $username)->first();

        // Mengambil total poin dari model Mahasiswa
        $mahasiswaData = $this->MahasiswaModel->getPointByNpm($npm);
        $totalPoints = $mahasiswaData['point'] ?? 0; // Menggunakan null coalescing operator untuk default 0
        // Memperbarui poin di session
        $session->set('point', $totalPoints);

        // Ambil semua transaksi yang tersedia
        $transaksi = $this->TransaksiModel->findAll(); // Pastikan model ini mengembalikan data yang sesuai
        $datatransaksi = $this->DataTransaksiModel->getRewardsByNpmAndValidation($npm, 'Sudah'); // Ambil reward yang sudah divalidasi

        $data = [
            'title' => 'Misi',
            // 'isLoggedIn' => $isLoggedIn,
            'npm' => $npm,
            'nama' => $nama,
            // 'mahasiswa' => $mahasiswa,
            'point' => $totalPoints,
            'transaksi' => $transaksi,
            'datatransaksi' => $datatransaksi
        ];

        return view('Marketplace/misi', $data);
    }

    public function reward()
    {
        $session = session();
        // $isLoggedIn = $session->get('isLoggedIn'); // Ambil status login dari sesi
        $nama = $session->get('nama');
        $npm = $session->get('npm');
        // $mahasiswa = $this->MahasiswaModel->where('nama', $username)->first();

        // Mengambil total poin dari model Mahasiswa
        $mahasiswaData = $this->MahasiswaModel->getPointByNpm($npm);
        $totalPoints = $mahasiswaData['point'] ?? 0; // Menggunakan null coalescing operator untuk default 0
        // Memperbarui poin di session
        $session->set('point', $totalPoints);

        // Ambil semua transaksi yang tersedia
        $transaksi = $this->TransaksiModel->findAll(); // Pastikan model ini mengembalikan data yang sesuai
        $datatransaksi = $this->DataTransaksiModel->getRewardsByNpmAndValidation($npm, 'Sudah'); // Ambil reward yang sudah divalidasi

        $data = [
            'title' => 'Reward',
            // 'isLoggedIn' => $isLoggedIn,
            'npm' => $npm,
            'nama' => $nama,
            // 'mahasiswa' => $mahasiswa,
            'point' => $totalPoints,
            'transaksi' => $transaksi,
            'datatransaksi' => $datatransaksi
        ];

        return view('Marketplace/reward', $data);
    }

    // Fungsi untuk mengklaim reward
    public function claimReward()
    {
        $session = session();
        $npm = $session->get('npm');

        // Validasi NPM
        if ($npm === null) {
            return redirect()->back()->with('error', 'User  not logged in.');
        }

        // Ambil data mahasiswa berdasarkan NPM
        $mahasiswa = $this->MahasiswaModel->findByNpm($npm);
        if ($mahasiswa === null) {
            return redirect()->back()->with('error', 'Mahasiswa not found.');
        }

        // // Ambil poin yang digunakan untuk klaim dari request
        // $poin_digunakan = $this->request->getPost('poin_digunakan');
        // $transaksi_id = $this->request->getPost('id_transaksi'); // Ambil ID transaksi

        // Ambil poin yang diberikan untuk klaim dari request
        $poin_diberikan = $this->request->getPost('poin_diberikan');
        $transaksi_id = $this->request->getPost('id_transaksi'); // Ambil ID transaksi

        // Validasi poin yang cukup
        // if ($mahasiswa['point'] < $poin_digunakan) {
        //     return redirect()->back()->with('error', 'Not enough points to claim this reward.');
        // }

        // Tandai reward sebagai sudah diambil
        // Pastikan $transaksi_id adalah ID yang valid
        if ($transaksi_id) {
            // Coba untuk memperbarui status klaim
            $updateStatus = $this->DataTransaksiModel->update($transaksi_id, ['claim' => 'Sudah']); // Tandai reward sebagai diambil

            // Periksa apakah pembaruan status berhasil
            if ($updateStatus) {
                // Jika berhasil, update poin mahasiswa
                $sisaPoin = $mahasiswa['point'] + $poin_diberikan; // Hitung sisa poin
                $this->MahasiswaModel->update($mahasiswa['id'], ['point' => $sisaPoin]); // Update poin mahasiswa

                return redirect()->back()->with('sukses', 'Reward Berhasil di Claim! Total points sekarang: ' . $sisaPoin);
            } else {
                return redirect()->back()->with('error', 'Failed to update claim status. Please try again.');
            }
        } else {
            return redirect()->back()->with('error', 'Invalid transaction ID.');
        }
    }

    // Fungsi Untuk Pembelian Produk
    // Tambahkan menggunakan redeem untuk belanja, dalam redeem terdapat point
    public function buy()
    {
        $session = session();
        $npm = $session->get('npm');

        // Validasi NPM
        if ($npm === null) {
            return redirect()->back()->with('gagal1', 'Silahkan Login Terlebih Dahulu !');
        }

        // Ambil data mahasiswa berdasarkan NPM
        $mahasiswa = $this->MahasiswaModel->findByNpm($npm);
        if ($mahasiswa === null) {
            return redirect()->back()->with('gagal', 'Mahasiswa Tidak ditemukan.');
        }

        $poin_digunakan = $this->request->getPost('poin_digunakan');

        // Validasi poin yang cukup
        if ($mahasiswa['point'] < $poin_digunakan) {
            return redirect()->back()->with('gagal1', 'Poin Tidak Cukup untuk Pembelian.');
        }

        // Proses pembelian
        $sisaPoin = $mahasiswa['point'] - $poin_digunakan;
        $this->MahasiswaModel->update($mahasiswa['id'], ['point' => $sisaPoin]);

        // Simpan transaksi ke dalam tabel data_transaksi
        $data_transaksi = [
            'npm' => $npm,
            'kode_jenis' => '102', // Pembelian
            'nama_transaksi' => $this->request->getPost('nama_transaksi'), // Ambil nama transaksi dari input
            'poin_digunakan' => $poin_digunakan,
            'tanggal_transaksi' => date('Y-m-d H:i:s'), // Format tanggal, Atur Format Zona Waktu
            'validation' => 'Belum', // Status validasi
            'claim' => 'Sudah' // Status claim
        ];

        // Simpan data transaksi
        $this->DataTransaksiModel->insert($data_transaksi);

        return redirect()->back()->with('sukses', 'Pembelian Berhasil ! Total points : ' . $sisaPoin . ' <br> Silahkan Tunggu Validasi');
    }

    // public function redeem()
    // {
    //     // Panggil fungsi cek_redeem_code
    //     $result = $this->your_model->cek_redeem_code();
    //     // tambahkan cek_redeem_code pada modelm untuk mengecek database

    //     // Proses hasil dari fungsi
    //     if ($result['status']) {
    //         // Jika redeem code valid
    //         $data = $result['data'];
    //         echo "Redeem code valid! Data: " . json_encode($data);
    //     } else {
    //         // Jika redeem code tidak valid atau terjadi error
    //         echo "Error: " . $result['message'];
    //     }
    // }

    // // Fungsi untuk mengajukan misi tambahan
    // public function misi_tambah()
    // {
    //     $session = session();
    //     $npm = $session->get('npm');

    //     // Validasi NPM
    //     if ($npm === null) {
    //         // return redirect()->back()->with('gagal', 'User  not logged in.');
    //         return redirect()->back()->with('gagal1', 'Silahkan Login Terlebih Dahulu .');
    //     }

    //     // Ambil data mahasiswa berdasarkan NPM
    //     $mahasiswa = $this->MahasiswaModel->findByNpm($npm);
    //     if ($mahasiswa === null) {
    //         return redirect()->back()->with('gagal1', 'Mahasiswa not found.');
    //     }

    //     // Pastikan request adalah POST
    //     if ($this->request->getMethod() === 'post') {
    //         // Ambil data dari form
    //         $nama_transaksi = $this->request->getPost('nama_transaksi');
    //         $poin_digunakan = $this->request->getPost('poin_digunakan');

    //         // Simpan transaksi misi tanpa menambahkan poin
    //         $data_transaksi = [
    //             'npm' => $npm,
    //             'kode_jenis' => '105', // Kode untuk misi tambahan
    //             'nama_transaksi' => $nama_transaksi,
    //             'poin_digunakan' => $poin_digunakan,
    //             'tanggal_transaksi' => date('Y-m-d H:i:s'), // Format tanggal
    //             'validation' => 'Belum', // Status validasi, misalnya 'Belum' sampai misi selesai
    //             'claim' => 'Belum' // Status klaim
    //         ];

    //         // Simpan data transaksi
    //         $this->DataTransaksiModel->insert($data_transaksi);

    //         // Set flashdata untuk pesan sukses
    //         return redirect()->back()->with('sukses', 'Misi berhasil diajukan. Tunggu konfirmasi untuk penambahan poin.');
    //     } else {
    //         // Set flashdata untuk pesan error jika request bukan POST
    //         return redirect()->back()->with('gagal1', 'Request tidak valid.');
    //     }
    // }

    public function misi_tambah()
    {
        $session = session();
        $npm = $session->get('npm');

        // Validasi NPM
        if ($npm === null) {
            return redirect()->back()->with('gagal1', 'Silahkan Login Terlebih Dahulu .');
        }

        // Ambil data mahasiswa berdasarkan NPM
        $mahasiswa = $this->MahasiswaModel->findByNpm($npm);
        if ($mahasiswa === null) {
            return redirect()->back()->with('gagal1', 'Mahasiswa not found.');
        }

        // Pastikan request adalah POST
        if ($this->request->getMethod() === 'post') {
            // Ambil data dari form
            $nama_transaksi = $this->request->getPost('nama_transaksi');
            $poin_digunakan = $this->request->getPost('poin_digunakan');
            $poin_diberikan = $this->request->getPost('poin_diberikan');

            // Validasi poin yang cukup
            if ($mahasiswa['point'] < $poin_digunakan) {
                return redirect()->back()->with('gagal1', 'Poin Tidak Cukup untuk mengajukan misi.');
            }

            // Kurangi poin mahasiswa
            $sisaPoin = $mahasiswa['point'] - $poin_digunakan;
            $this->MahasiswaModel->update($mahasiswa['id'], ['point' => $sisaPoin]);

            // Simpan transaksi misi
            $data_transaksi = [
                'npm' => $npm,
                'kode_jenis' => '105', // Kode untuk misi tambahan
                'nama_transaksi' => $nama_transaksi,
                'poin_digunakan' => $poin_digunakan,
                'poin_diberikan' => $poin_diberikan,
                'tanggal_transaksi' => date('Y-m-d H:i:s'), // Format tanggal
                'validation' => 'Belum', // Status validasi, misalnya 'Belum' sampai misi selesai
                'claim' => 'Belum' // Status klaim
            ];

            // Simpan data transaksi
            $this->DataTransaksiModel->insert($data_transaksi);

            // Set flashdata untuk pesan sukses
            return redirect()->back()->with('sukses', 'Misi berhasil diajukan. Tunggu konfirmasi untuk penambahan poin. Total points sekarang: ' . $sisaPoin);
        } else {
            // Set flashdata untuk pesan error jika request bukan POST
            return redirect()->back()->with('gagal1', 'Request tidak valid.');
        }
    }

    public function quis()
    {
        $session = session();
        $nama = $session->get('nama');

        $data = [
            'title' => 'Market Point',
            'nama' => $nama,
            'quis' => $this->QuisModel->findAll(), // Ambil semua data kuis dari database
        ];
        return view('User/Page/quis', $data);
    }

    public function kirimJawaban()
    {
        $session = session();
        $npm = $session->get('npm');

        // Validasi NPM
        if ($npm === null) {
            return redirect()->back()->with('gagal1', 'Silahkan login terlebih dahulu.');
        }

        // Ambil semua data kuis dari tabel quis
        $quisData = $this->QuisModel->findAll(); // Pastikan model mengembalikan data yang sesuai

        // Siapkan array untuk menyimpan jawaban benar dan poin
        $correctAnswers = [];
        $pointsPerQuestion = [];

        foreach ($quisData as $quis) {
            $correctAnswers[$quis['id']] = $quis['jawaban_benar']; // Simpan jawaban benar
            $pointsPerQuestion[$quis['id']] = $quis['poin']; // Simpan poin per pertanyaan
        }

        // Ambil jawaban dari pengguna
        $userAnswers = $this->request->getPost('jawaban') ?? []; // Inisialisasi sebagai array kosong jika null

        // Periksa apakah ada jawaban yang dipilih
        if (empty($userAnswers)) {
            return redirect()->back()->with('gagal1', 'Silakan pilih jawaban yang tersedia.');
        }

        // Hitung poin
        $totalPoints = 0;
        foreach ($userAnswers as $idPertanyaan => $jawabanMahasiswa) {
            if (isset($correctAnswers[$idPertanyaan]) && $jawabanMahasiswa === $correctAnswers[$idPertanyaan]) {
                $totalPoints += $pointsPerQuestion[$idPertanyaan]; // Tambahkan poin berdasarkan jawaban benar
            }
        }

        // Ambil data mahasiswa berdasarkan NPM
        $mahasiswa = $this->MahasiswaModel->findByNpm($npm);
        if ($mahasiswa === null) {
            return redirect()->back()->with('gagal1', 'Mahasiswa tidak ditemukan.');
        }

        // Update poin mahasiswa
        $newPoints = $mahasiswa['point'] + $totalPoints;
        $this->MahasiswaModel->update($mahasiswa['id'], ['point' => $newPoints]);

        // Setelah quis selesai dikerjakan
        session()->set('quis_selesai', true);
        // Set flashdata untuk pesan sukses
        return redirect()->back()->with('sukses', "Selamat! Anda mendapatkan $totalPoints poin tambahan. Total poin Anda sekarang adalah $newPoints.");
    }
}
