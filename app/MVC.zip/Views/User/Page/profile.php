<?= $this->extend('User/Template/dashboard'); ?>

<?= $this->section('content_user'); ?>

<div class="content-wrapper">
    <div class="container">
        <div class="content-header">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"> <?= $title; ?> </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/Role_User">User</a></li>
                        <li class="breadcrumb-item active"><?= $title; ?></li>
                    </ol>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="col-lg-8">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="/img/admin.jpg" class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <h5 class="card-title"><b>Nama :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $nama; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>NPM :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $npm; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>Email :</b></h5>
                                        <?php if (!empty($email)) : ?>
                                            <li class="list-group-item">
                                                <h4><?= $email; ?></h4>
                                            </li>
                                        <?php else : ?>
                                            <li class="list-group-item">
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#modalEmail" class="small-box-footer">Tambahkan Email</a>
                                                </h5>
                                            </li>
                                        <?php endif; ?>
                                        <h5 class="card-title"><b>Alamat IP :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $_SERVER['REMOTE_ADDR']; ?></h4>
                                        </li>
                                        <!-- <h5 class="card-title"><b>Token API :</b></h5>
                                        <li class="list-group-item">
                                            <input type="hidden" id="tokenInput" value="<?= $token; ?>">
                                            <button class="btn btn-primary btn-block" type="button" onclick="copyToken()">
                                                <i class="fas fa-key"></i> Copy Token API
                                            </button>
                                        </li> -->
                                        <!-- <h5 class="card-title"><b>Point :</b></h5>
                                        <li class="list-group-item">
                                            <h4 id="current-point"><?= $point; ?></h4>
                                        </li> -->
                                        <!-- <h5 class="card-title"><b>Point :</b></h5>
                                    <li class="list-group-item">
                                        <h4><?= $point; ?></h4>
                                    </li>
                                    <h5 class="card-title"><b>Level : </b> </h5>
                                    <li class="list-group-item">
                                        <h4>
                                            <?php
                                            $selectedBadge = null;
                                            foreach ($badges as $badge) {
                                                if ($point >= $badge['point']) {
                                                    $selectedBadge = $badge;
                                                } else {
                                                    break; // Menghentikan iterasi jika poin mahasiswa tidak cukup untuk badge berikutnya
                                                }
                                            }

                                            if ($selectedBadge !== null) {
                                                echo $selectedBadge['nama'];
                                            } else {
                                                echo 'Tidak ada badge';
                                            }
                                            ?>
                                        </h4>
                                    </li>
                                    <h5 class="card-title"><b>Badges : </b></h5>
                                    <li class="list-group-item">
                                        <?php
                                        $selectedBadge = null;
                                        foreach ($badges as $badge) {
                                            if ($point >= $badge['point']) {
                                                $selectedBadge = $badge;
                                            } else {
                                                break; // Menghentikan iterasi jika poin mahasiswa tidak cukup untuk badge berikutnya
                                            }
                                        }

                                        if ($selectedBadge !== null) {
                                            echo '<img src="data:image/png;base64,' . base64_encode($selectedBadge['badges']) . '" width="85">';
                                        } else {
                                            echo 'Tidak ada badge';
                                        }
                                        ?>
                                    </li> -->
                                        <button type=" button" class="btn btn-info" data-toggle="modal" data-target="#modalEdit<?= $npm; ?>">Edit Profil</button>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Riwayat Transaksi</h3>
                        </div>
                        <div class="card-body">
                            <table id="tabel-transaksi" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Jenis</th>
                                        <th>Point</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
                                </tbody>
                            </table>
                        </div>
                    </div> -->
                </div>
            </div>
        </section>
    </div>
</div>


<!-- Modal box Tambah Email -->
<div class="modal fade" id="modalEmail" tabindex="-1" role="dialog" aria-labelledby="addEmailModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEmailModalLabel">Tambahkan Email</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Add your form or content for adding email here -->
                <!-- Example: -->
                <form action="/Role_User/save_email" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?= $id; ?>">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Email</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!--Data Modal Box Edit Data-->
<div class="modal fade" id="modalEdit<?= $npm; ?>">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content ">
            <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="staticBackdropLabel">Edit <?= $title; ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>  
            <form action="/Role_User/Update_Profile" method="post">
                <div class="modal-body">               
                    <input type="hidden" name="id" value="<?= $id; ?>">

                    <div class="form-group">
                        <label for="nama">Nama Lengkap</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" id="nama" 
                                name="nama" value="<?= $nama; ?>" required
                                placeholder="Masukkan nama lengkap">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="npm">NPM</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-hashtag"></i></span>
                            </div>
                            <input type="text" class="form-control" id="npm" 
                                name="npm" value="<?= $npm; ?>" required
                                placeholder="Masukkan NPM">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            </div>
                            <input type="email" class="form-control" id="email" 
                                name="email" value="<?= $email; ?>" required
                                placeholder="Masukkan email">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fas fa-times"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endsection(); ?>

<?= $this->section('scripts'); ?>
<script>
function copyToken() {
    var tokenInput = document.getElementById('tokenInput');
    
    // Buat temporary textarea untuk menyalin teks
    var tempTextArea = document.createElement('textarea');
    tempTextArea.value = tokenInput.value;
    document.body.appendChild(tempTextArea);
    tempTextArea.select();
    document.execCommand('copy');
    document.body.removeChild(tempTextArea);
    
    // Tampilkan notifikasi menggunakan SweetAlert2
    Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: 'Token API berhasil disalin ke clipboard',
        showConfirmButton: false,
        timer: 1500
    });
}
</script>
<?= $this->endSection(); ?>