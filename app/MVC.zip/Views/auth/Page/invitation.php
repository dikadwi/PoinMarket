<html lang="id" class="notranslate" translate="no">
<!-- https://satumomen.com/preview/wayang-kulit -->
<!-- https://satumomen.com/preview/javanese -->
<!-- https://satumomen.com/preview/feminime-javanese -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="color-scheme" content="light only">
    <meta name="format-detection" content="telephone=no">
    <meta name="google" content="notranslate">
    <title>Wedding - Feminime Javanese</title>
    <meta name="title" content="Wedding  - Feminime Javanese">
    <meta name="description" content="Undangan website syari adat jawa, java cream dan gold flowers tanpa foto">
    <meta itemprop="image" content="https://satumomen.com/themes/feminime-javanese/feminime-javanese.jpg">
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://satumomen.com/preview/feminime-javanese">
    <meta property="og:title" content="Wedding  - Feminime Javanese">
    <meta property="og:description" content="Undangan website syari adat jawa, java cream dan gold flowers tanpa foto">
    <meta property="og:image" content="https://satumomen.com/themes/feminime-javanese/feminime-javanese.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">


    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": "Wedding  - Feminime Javanese",
            "image": "https://satumomen.com/themes/feminime-javanese/feminime-javanese.jpg",
            "description": "Undangan website syari adat jawa, java cream dan gold flowers tanpa foto",
            "brand": {
                "@type": "Brand",
                "name": "Satu Momen"
            },
            "review": {
                "@type": "Review",
                "reviewRating": {
                    "@type": "Rating",
                    "ratingValue": "5",
                    "bestRating": "5"
                },
                "author": {
                    "@type": "Person",
                    "name": "Elsa Gunayanti"
                }
            },
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "reviewCount": "381"
            },
            "offers": {
                "@type": "Offer",
                "url": "https://satumomen.com/harga",
                "priceCurrency": "IDR",
                "price": "75000",
                "availability": "https://schema.org/InStock",
                "itemCondition": "https://schema.org/NewCondition"
            }
        }
    </script>


    <!-- css -->
    <link rel="stylesheet" href="/plugins/animate.css@4.1.1/animate.min.css">
    <link href="https://satumomen.com/themes/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/@phosphor-icons/web@2.0.3/src/fill/style.css">
    <link href="https://satumomen.com/themes/themesv2.css?v=241207" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Kalnia:wght@400;700&family=MonteCarlo&family=Quintessential&display=swap');

        :root {
            --inv-bg: #f6f2ef;
            --inv-base: #433318;
            --inv-accent: #a48d66;
            --inv-border: #a48d66;
            --font-base: 'Quintessential', serif;
            --font-accent: 'Kalnia', serif;
            --font-latin: 'MonteCarlo', cursive;
            --menu-bg: #e7e4df;
            --menu-inactive: #a48d66;
            --menu-active: #a48d66;
            --btn-color: #ffffff;
        }
    </style>


    <style>
        @import url('/fonts/brittany_signature/BrittanySignature.css');
        @import url('/fonts/photograph_signature/fonts.css');
        @import url('/fonts/heatwood/Heatwood.css');

        .font-brittany-signature {
            font-family: 'Brittany Signature';
            line-height: 1.6 !important;
        }

        .font-photograph-signature {
            font-family: 'Photograph Signature';
            line-height: 1.6 !important;
        }

        .font-heatwood {
            font-family: 'Heatwood';
            line-height: 3 !important;
        }
    </style>
    <style>
        #noty_layout__bottom,
        #noty_layout__bottomCenter,
        #noty_layout__bottomLeft,
        #noty_layout__bottomRight,
        #noty_layout__center,
        #noty_layout__centerLeft,
        #noty_layout__centerRight,
        #noty_layout__top,
        #noty_layout__topCenter,
        #noty_layout__topLeft,
        #noty_layout__topRight,
        .noty_layout_mixin {
            -webkit-font-smoothing: subpixel-antialiased;
            backface-visibility: hidden;
            filter: blur(0);
            -webkit-filter: blur(0);
            margin: 0;
            max-width: 90%;
            padding: 0;
            position: fixed;
            transform: translateZ(0) scale(1);
            z-index: 9999999
        }

        #noty_layout__top {
            left: 5%;
            top: 0;
            width: 90%
        }

        #noty_layout__topLeft {
            left: 20px;
            top: 20px;
            width: 325px
        }

        #noty_layout__topCenter {
            left: 50%;
            top: 5%;
            transform: translate(calc(-50% - .5px)) translateZ(0) scale(1);
            width: 325px
        }

        #noty_layout__topRight {
            right: 20px;
            top: 20px;
            width: 325px
        }

        #noty_layout__bottom {
            bottom: 0;
            left: 5%;
            width: 90%
        }

        #noty_layout__bottomLeft {
            bottom: 20px;
            left: 20px;
            width: 325px
        }

        #noty_layout__bottomCenter {
            bottom: 5%;
            left: 50%;
            transform: translate(calc(-50% - .5px)) translateZ(0) scale(1);
            width: 325px
        }

        #noty_layout__bottomRight {
            bottom: 20px;
            right: 20px;
            width: 325px
        }

        #noty_layout__center {
            left: 50%;
            top: 50%;
            transform: translate(calc(-50% - .5px), calc(-50% - .5px)) translateZ(0) scale(1);
            width: 325px
        }

        #noty_layout__centerLeft {
            left: 20px
        }

        #noty_layout__centerLeft,
        #noty_layout__centerRight {
            top: 50%;
            transform: translateY(calc(-50% - .5px)) translateZ(0) scale(1);
            width: 325px
        }

        #noty_layout__centerRight {
            right: 20px
        }

        .noty_progressbar {
            display: none
        }

        .noty_has_timeout .noty_progressbar {
            background-color: #646464;
            bottom: 0;
            display: block;
            filter: alpha(opacity=10);
            height: 3px;
            left: 0;
            opacity: .2;
            position: absolute;
            width: 100%
        }

        .noty_bar {
            -webkit-font-smoothing: subpixel-antialiased;
            -webkit-backface-visibility: hidden;
            overflow: hidden;
            transform: translate(0) scale(1)
        }

        .noty_effects_open {
            animation: noty_anim_in .5s cubic-bezier(.68, -.55, .265, 1.55);
            animation-fill-mode: forwards;
            opacity: 0;
            transform: translate(50%)
        }

        .noty_effects_close {
            animation: noty_anim_out .5s cubic-bezier(.68, -.55, .265, 1.55);
            animation-fill-mode: forwards
        }

        .noty_fix_effects_height {
            animation: noty_anim_height 75ms ease-out
        }

        .noty_close_with_click {
            cursor: pointer
        }

        .noty_close_button {
            background-color: rgba(0, 0, 0, .05);
            border-radius: 2px;
            cursor: pointer;
            font-weight: 700;
            height: 20px;
            line-height: 20px;
            position: absolute;
            right: 2px;
            text-align: center;
            top: 2px;
            transition: all .2s ease-out;
            width: 20px
        }

        .noty_close_button:hover {
            background-color: rgba(0, 0, 0, .1)
        }

        .noty_modal {
            background-color: #000;
            height: 100%;
            left: 0;
            opacity: .3;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 10000
        }

        .noty_modal.noty_modal_open {
            animation: noty_modal_in .3s ease-out;
            opacity: 0
        }

        .noty_modal.noty_modal_close {
            animation: noty_modal_out .3s ease-out;
            animation-fill-mode: forwards
        }

        @keyframes noty_modal_in {
            to {
                opacity: .3
            }
        }

        @keyframes noty_modal_out {
            to {
                opacity: 0
            }
        }

        @keyframes noty_anim_in {
            to {
                opacity: 1;
                transform: translate(0)
            }
        }

        @keyframes noty_anim_out {
            to {
                opacity: 0;
                transform: translate(50%)
            }
        }

        @keyframes noty_anim_height {
            to {
                height: 0
            }
        }

        .noty_theme__relax.noty_bar {
            border-radius: 2px;
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__relax.noty_bar .noty_body {
            padding: 10px
        }

        .noty_theme__relax.noty_bar .noty_buttons {
            border-top: 1px solid #e7e7e7;
            padding: 5px 10px
        }

        .noty_theme__relax.noty_type__alert,
        .noty_theme__relax.noty_type__notification {
            background-color: #fff;
            border: 1px solid #dedede;
            color: #444
        }

        .noty_theme__relax.noty_type__warning {
            background-color: #ffeaa8;
            border: 1px solid #ffc237;
            color: #826200
        }

        .noty_theme__relax.noty_type__warning .noty_buttons {
            border-color: #dfaa30
        }

        .noty_theme__relax.noty_type__error {
            background-color: #ff8181;
            border: 1px solid #e25353;
            color: #fff
        }

        .noty_theme__relax.noty_type__error .noty_buttons {
            border-color: darkred
        }

        .noty_theme__relax.noty_type__info,
        .noty_theme__relax.noty_type__information {
            background-color: #78c5e7;
            border: 1px solid #3badd6;
            color: #fff
        }

        .noty_theme__relax.noty_type__info .noty_buttons,
        .noty_theme__relax.noty_type__information .noty_buttons {
            border-color: #0b90c4
        }

        .noty_theme__relax.noty_type__success {
            background-color: #bcf5bc;
            border: 1px solid #7cdd77;
            color: #006400
        }

        .noty_theme__relax.noty_type__success .noty_buttons {
            border-color: #50c24e
        }

        .noty_theme__metroui.noty_bar {
            box-shadow: 0 0 5px 0 rgba(0, 0, 0, .298);
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__metroui.noty_bar .noty_progressbar {
            background-color: #000;
            bottom: 0;
            filter: alpha(opacity=20);
            height: 3px;
            left: 0;
            opacity: .2;
            position: absolute;
            width: 100%
        }

        .noty_theme__metroui.noty_bar .noty_body {
            font-size: 14px;
            padding: 1.25em
        }

        .noty_theme__metroui.noty_bar .noty_buttons {
            padding: 0 10px .5em
        }

        .noty_theme__metroui.noty_type__alert,
        .noty_theme__metroui.noty_type__notification {
            background-color: #fff;
            color: #1d1d1d
        }

        .noty_theme__metroui.noty_type__warning {
            background-color: #fa6800;
            color: #fff
        }

        .noty_theme__metroui.noty_type__error {
            background-color: #ce352c;
            color: #fff
        }

        .noty_theme__metroui.noty_type__info,
        .noty_theme__metroui.noty_type__information {
            background-color: #1ba1e2;
            color: #fff
        }

        .noty_theme__metroui.noty_type__success {
            background-color: #60a917;
            color: #fff
        }

        .noty_theme__mint.noty_bar {
            border-radius: 2px;
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__mint.noty_bar .noty_body {
            font-size: 14px;
            padding: 10px
        }

        .noty_theme__mint.noty_bar .noty_buttons {
            padding: 10px
        }

        .noty_theme__mint.noty_type__alert,
        .noty_theme__mint.noty_type__notification {
            background-color: #fff;
            border-bottom: 1px solid #d1d1d1;
            color: #2f2f2f
        }

        .noty_theme__mint.noty_type__warning {
            background-color: #ffae42;
            border-bottom: 1px solid #e89f3c;
            color: #fff
        }

        .noty_theme__mint.noty_type__error {
            background-color: #de636f;
            border-bottom: 1px solid #ca5a65;
            color: #fff
        }

        .noty_theme__mint.noty_type__info,
        .noty_theme__mint.noty_type__information {
            background-color: #7f7eff;
            border-bottom: 1px solid #7473e8;
            color: #fff
        }

        .noty_theme__mint.noty_type__success {
            background-color: #afc765;
            border-bottom: 1px solid #a0b55c;
            color: #fff
        }

        .noty_theme__sunset.noty_bar {
            border-radius: 2px;
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__sunset.noty_bar .noty_body {
            font-size: 14px;
            padding: 10px;
            text-shadow: 1px 1px 1px rgba(0, 0, 0, .1)
        }

        .noty_theme__sunset.noty_bar .noty_buttons {
            padding: 10px
        }

        .noty_theme__sunset.noty_type__alert,
        .noty_theme__sunset.noty_type__notification {
            background-color: #073b4c;
            color: #fff
        }

        .noty_theme__sunset.noty_type__alert .noty_progressbar,
        .noty_theme__sunset.noty_type__notification .noty_progressbar {
            background-color: #fff
        }

        .noty_theme__sunset.noty_type__warning {
            background-color: #ffd166;
            color: #fff
        }

        .noty_theme__sunset.noty_type__error {
            background-color: #ef476f;
            color: #fff
        }

        .noty_theme__sunset.noty_type__error .noty_progressbar {
            opacity: .4
        }

        .noty_theme__sunset.noty_type__info,
        .noty_theme__sunset.noty_type__information {
            background-color: #118ab2;
            color: #fff
        }

        .noty_theme__sunset.noty_type__info .noty_progressbar,
        .noty_theme__sunset.noty_type__information .noty_progressbar {
            opacity: .6
        }

        .noty_theme__sunset.noty_type__success {
            background-color: #06d6a0;
            color: #fff
        }

        .noty_theme__bootstrap-v3.noty_bar {
            border: 1px solid transparent;
            border-radius: 4px;
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__bootstrap-v3.noty_bar .noty_body {
            padding: 15px
        }

        .noty_theme__bootstrap-v3.noty_bar .noty_buttons {
            padding: 10px
        }

        .noty_theme__bootstrap-v3.noty_bar .noty_close_button {
            background: transparent;
            color: #000;
            filter: alpha(opacity=20);
            font-size: 21px;
            font-weight: 700;
            line-height: 1;
            opacity: .2;
            text-shadow: 0 1px 0 #fff
        }

        .noty_theme__bootstrap-v3.noty_bar .noty_close_button:hover {
            background: transparent;
            cursor: pointer;
            filter: alpha(opacity=50);
            opacity: .5;
            text-decoration: none
        }

        .noty_theme__bootstrap-v3.noty_type__alert,
        .noty_theme__bootstrap-v3.noty_type__notification {
            background-color: #fff;
            color: inherit
        }

        .noty_theme__bootstrap-v3.noty_type__warning {
            background-color: #fcf8e3;
            border-color: #faebcc;
            color: #8a6d3b
        }

        .noty_theme__bootstrap-v3.noty_type__error {
            background-color: #f2dede;
            border-color: #ebccd1;
            color: #a94442
        }

        .noty_theme__bootstrap-v3.noty_type__info,
        .noty_theme__bootstrap-v3.noty_type__information {
            background-color: #d9edf7;
            border-color: #bce8f1;
            color: #31708f
        }

        .noty_theme__bootstrap-v3.noty_type__success {
            background-color: #dff0d8;
            border-color: #d6e9c6;
            color: #3c763d
        }

        .noty_theme__bootstrap-v4.noty_bar {
            border: 1px solid transparent;
            border-radius: .25rem;
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__bootstrap-v4.noty_bar .noty_body {
            padding: .75rem 1.25rem
        }

        .noty_theme__bootstrap-v4.noty_bar .noty_buttons {
            padding: 10px
        }

        .noty_theme__bootstrap-v4.noty_bar .noty_close_button {
            background: transparent;
            color: #000;
            filter: alpha(opacity=20);
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 1;
            opacity: .5;
            text-shadow: 0 1px 0 #fff
        }

        .noty_theme__bootstrap-v4.noty_bar .noty_close_button:hover {
            background: transparent;
            cursor: pointer;
            filter: alpha(opacity=50);
            opacity: .75;
            text-decoration: none
        }

        .noty_theme__bootstrap-v4.noty_type__alert,
        .noty_theme__bootstrap-v4.noty_type__notification {
            background-color: #fff;
            color: inherit
        }

        .noty_theme__bootstrap-v4.noty_type__warning {
            background-color: #fcf8e3;
            border-color: #faebcc;
            color: #8a6d3b
        }

        .noty_theme__bootstrap-v4.noty_type__error {
            background-color: #f2dede;
            border-color: #ebccd1;
            color: #a94442
        }

        .noty_theme__bootstrap-v4.noty_type__info,
        .noty_theme__bootstrap-v4.noty_type__information {
            background-color: #d9edf7;
            border-color: #bce8f1;
            color: #31708f
        }

        .noty_theme__bootstrap-v4.noty_type__success {
            background-color: #dff0d8;
            border-color: #d6e9c6;
            color: #3c763d
        }

        .noty_theme__semanticui.noty_bar {
            border: 1px solid transparent;
            border-radius: .28571429rem;
            box-shadow: inset 0 0 0 1px rgba(34, 36, 38, .22), 0 0 0 0 transparent;
            font-size: 1em;
            margin: 4px 0;
            overflow: hidden;
            position: relative
        }

        .noty_theme__semanticui.noty_bar .noty_body {
            line-height: 1.4285em;
            padding: 1em 1.5em
        }

        .noty_theme__semanticui.noty_bar .noty_buttons {
            padding: 10px
        }

        .noty_theme__semanticui.noty_type__alert,
        .noty_theme__semanticui.noty_type__notification {
            background-color: #f8f8f9;
            color: rgba(0, 0, 0, .87)
        }

        .noty_theme__semanticui.noty_type__warning {
            background-color: #fffaf3;
            box-shadow: inset 0 0 0 1px #c9ba9b, 0 0 0 0 transparent;
            color: #573a08
        }

        .noty_theme__semanticui.noty_type__error {
            background-color: #fff6f6;
            box-shadow: inset 0 0 0 1px #e0b4b4, 0 0 0 0 transparent;
            color: #9f3a38
        }

        .noty_theme__semanticui.noty_type__info,
        .noty_theme__semanticui.noty_type__information {
            background-color: #f8ffff;
            box-shadow: inset 0 0 0 1px #a9d5de, 0 0 0 0 transparent;
            color: #276f86
        }

        .noty_theme__semanticui.noty_type__success {
            background-color: #fcfff5;
            box-shadow: inset 0 0 0 1px #a3c293, 0 0 0 0 transparent;
            color: #2c662d
        }

        .noty_theme__nest.noty_bar {
            border-radius: 2px;
            box-shadow: 5px 4px 10px 0 rgba(0, 0, 0, .098);
            margin: 0 0 15px;
            overflow: hidden;
            position: relative
        }

        .noty_theme__nest.noty_bar .noty_body {
            font-size: 14px;
            padding: 10px;
            text-shadow: 1px 1px 1px rgba(0, 0, 0, .1)
        }

        .noty_theme__nest.noty_bar .noty_buttons {
            padding: 10px
        }

        .noty_layout .noty_theme__nest.noty_bar {
            z-index: 5
        }

        .noty_layout .noty_theme__nest.noty_bar:nth-child(2) {
            margin-left: 4px;
            margin-right: -4px;
            margin-top: 4px;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 4
        }

        .noty_layout .noty_theme__nest.noty_bar:nth-child(3) {
            margin-left: 8px;
            margin-right: -8px;
            margin-top: 8px;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 3
        }

        .noty_layout .noty_theme__nest.noty_bar:nth-child(4) {
            margin-left: 12px;
            margin-right: -12px;
            margin-top: 12px;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 2
        }

        .noty_layout .noty_theme__nest.noty_bar:nth-child(5) {
            margin-left: 16px;
            margin-right: -16px;
            margin-top: 16px;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 1
        }

        .noty_layout .noty_theme__nest.noty_bar:nth-child(n+6) {
            margin-left: 20px;
            margin-right: -20px;
            margin-top: 20px;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: -1
        }

        #noty_layout__bottomLeft .noty_theme__nest.noty_bar:nth-child(2),
        #noty_layout__topLeft .noty_theme__nest.noty_bar:nth-child(2) {
            margin-left: -4px;
            margin-right: 4px;
            margin-top: 4px
        }

        #noty_layout__bottomLeft .noty_theme__nest.noty_bar:nth-child(3),
        #noty_layout__topLeft .noty_theme__nest.noty_bar:nth-child(3) {
            margin-left: -8px;
            margin-right: 8px;
            margin-top: 8px
        }

        #noty_layout__bottomLeft .noty_theme__nest.noty_bar:nth-child(4),
        #noty_layout__topLeft .noty_theme__nest.noty_bar:nth-child(4) {
            margin-left: -12px;
            margin-right: 12px;
            margin-top: 12px
        }

        #noty_layout__bottomLeft .noty_theme__nest.noty_bar:nth-child(5),
        #noty_layout__topLeft .noty_theme__nest.noty_bar:nth-child(5) {
            margin-left: -16px;
            margin-right: 16px;
            margin-top: 16px
        }

        #noty_layout__bottomLeft .noty_theme__nest.noty_bar:nth-child(n+6),
        #noty_layout__topLeft .noty_theme__nest.noty_bar:nth-child(n+6) {
            margin-left: -20px;
            margin-right: 20px;
            margin-top: 20px
        }

        .noty_theme__nest.noty_type__alert,
        .noty_theme__nest.noty_type__notification {
            background-color: #073b4c;
            color: #fff
        }

        .noty_theme__nest.noty_type__alert .noty_progressbar,
        .noty_theme__nest.noty_type__notification .noty_progressbar {
            background-color: #fff
        }

        .noty_theme__nest.noty_type__warning {
            background-color: #ffd166;
            color: #fff
        }

        .noty_theme__nest.noty_type__error {
            background-color: #ef476f;
            color: #fff
        }

        .noty_theme__nest.noty_type__error .noty_progressbar {
            opacity: .4
        }

        .noty_theme__nest.noty_type__info,
        .noty_theme__nest.noty_type__information {
            background-color: #118ab2;
            color: #fff
        }

        .noty_theme__nest.noty_type__info .noty_progressbar,
        .noty_theme__nest.noty_type__information .noty_progressbar {
            opacity: .6
        }

        .noty_theme__nest.noty_type__success {
            background-color: #06d6a0;
            color: #fff
        }
    </style>
</head>

<body>
    <main id="app">
        <div id="modalOverlay" class="modal-backdrop fade" style="display: none;"></div>
        <div id="loader" class="loader-wrapper" style="display: none;"><span class="loader"><span class="loader-inner"></span></span></div>
        <!-- <audio id="music" loop="loop" autoplay="autoplay">
            <source src="https://assets.satumomen.com/musics/reff-nyoman-paul-andi-rianto-the-way-you-look-at-me.mp3">
        </audio> -->
        <div id="workspace-container" class="position-fixed h-100 w-100" style="overflow: hidden;">
            <div id="panZoom" class="position-fixed h-100 w-100" style="inset: 0px; transform-origin: 50% 50%; transform: scale(1.00272) translate(0px, 0px);">
                <div class="h-100 w-100 d-flex align-items-center justify-content-center">
                    <div class="canvas" style="height: 736px;">
                        <div id="satuMomen" data-guest="Nama Tamu" data-group="VIP" style="height: 736px;">
                            <div class="satumomen_track">
                                <ul class="satumomen_list">
                                    <li class="satumomen_slide satumomen_cover" style="">
                                        <div class="container-mobile cover" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="d-flex flex-column justify-content-center align-items-center" style="height: 100%;">
                                                <div class="mx-auto image-editable animate__animated animate__fadeInDown animate__slower" style="width: 100px; height: 172px; overflow: hidden;"><img src="/themes/feminime-javanese/gunungan.webp" alt="gunungan.webp" style="width: 100%; height: 100%; object-fit: contain;"></div>
                                                <div class="text-center my-5">
                                                    <div class="editable color-accent justify-content-center animate__animated animate__fadeInDown animate__slower font-accent" style="font-size: 36px; line-height: 1; animation-delay: 0.5s;">SACHARISSA</div>
                                                    <div class="editable color-accent justify-content-center animate__animated animate__zoomIn animate__slower font-accent" style="font-size: 36px; line-height: 1; animation-delay: 1s;">&amp;</div>
                                                    <div class="editable color-accent justify-content-center animate__animated animate__fadeInUp animate__slower font-accent" style="font-size: 36px; line-height: 1; animation-delay: 1.5s;">ALDI MEIKO</div>
                                                </div>
                                                <div class="mt-3 text-center mx-auto" style="max-width: 300px;">
                                                    <div class="text-center mb-3 p-2 animate__animated animate__zoomIn animate__slower" style="border-radius: 0.5rem;">
                                                        <div class="editable mb-1 animate__animated animate__fadeInUp animate__slower" style="font-size: 14px;">Kepada Yth.<br>Bapak/Ibu/Saudara/i</div>
                                                        <div id="guestNameSlot" class="editable color-accent h5 font-weight-bold mb-1 animate__animated animate__fadeInUp animate__slower" style="font-size: 16px;">Nama Tamu</div>
                                                    </div><button class="btn-open-invitation btn btn-primary rounded-pill mb-4 animate__animated animate__fadeInUp animate__slow d-none" style="font-size: 14px;">Open Invitation</button>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="d-flex flex-olumn justify-content-center align-items-center" style="height: 100%;">
                                                <div class="text-center animate__animated animate__fadeInUp animate__slower">
                                                    <div class="editable quotes mb-3 font-italic" style="font-size: 14.4px;">Dan di antara tanda-tanda (kebesaran)-Nya ialah Dia menciptakan pasangan-pasangan untukmu dari jenismu sendiri, agar kamu cenderung dan merasa tenteram kepadanya, dan Dia menjadikan di antaramu rasa kasih dan sayang. Sungguh, pada yang demikian itu benar-benar terdapat tanda-tanda (kebesaran Allah) bagi kaum yang berpikir.</div>
                                                    <div class="editable" style="font-size: 14.4px;">(QS. Ar-Ruum 30 : 21)</div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="w-100 d-flex flex-column justify-content-center align-items-center" style="height: 100%;">
                                                <div class="editable mb-2 text-center animate__animated animate__fadeInDown animate__slower font-italic" style="font-size: 14.4px;">Bismillahirrahmanirrahim</div>
                                                <div class="editable color-accent mb-2 text-center animate__animated animate__fadeInDown animate__slower font-italic" style="font-size: 14.4px;">Assalamualaikum Warahmatullohi Wabarakatuh</div>
                                                <div class="editable text-center mb-4 animate__animated animate__fadeInDown animate__fast" style="font-size: 14.4px;">Maha Suci Allah SWT Yang telah menciptakan makhluk-Nya berpasang-pasangan, Ya Allah dengan kerendahan hati, perkenankanlah kami menikahkan putra-putri kami tercinta</div>
                                                <div class="text-center" style="position: relative;">
                                                    <div class="editable color-accent h4 mb-2 animate__animated animate__fadeInLeft animate__slower font-accent" style="font-size: 23px;">dr. SACHARISSA ZERLINA TSARWAH THIRAFI</div>
                                                    <div class="editable animate__animated animate__zoomIn animate__slower" style="font-size: 14.4px;">Putri ke dua Bpk. Dr. H. Rusman Nurdin, S.Sen., M.Sn.<br>&amp; Ibu Hj. Lilis Sriyeti, BA.</div> <a href="https://instagram.com/" rel="nofollow noreferrer noopener" target="_blank" class="mt-2 link btn btn-primary btn-sm rounded-pill animate__animated animate__fadeInUp animate__slower">@instagram</a>
                                                </div>
                                                <div class="mt-4 mb-3 editable text-center color-accent animate__animated animate__zoomIn animate__slower font-italic font-accent" style="font-size: 14px;">dengan</div>
                                                <div class="text-center" style="position: relative;">
                                                    <div class="editable color-accent h4 mb-2 animate__animated animate__fadeInRight animate__slower font-accent" style="font-size: 23px;">dr. ALDI MEIKO RINGGA PRABUDI</div>
                                                    <div class="editable animate__animated animate__zoomIn animate__slower" style="font-size: 14.4px;">Putra ke empat Bpk. Supriatna (Alm)<br>&amp; Ibu Eti Rohayati</div> <a href="https://instagram.com/" rel="nofollow noreferrer noopener" target="_blank" class="mt-2 link btn btn-primary btn-sm rounded-pill animate__animated animate__fadeInUp animate__slower">@instagram</a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="h-100 d-flex justify-content-center align-items-center">
                                                <div class="w-100">
                                                    <div class="d-flex justify-content-center align-items-center mb-4">
                                                        <div class="text-center animate__animated animate__fadeInDown animate__slower">
                                                            <div class="editable color-accent font-weight-bold" style="font-size: 16px;">Akad Nikah<br>Sabtu, 17 Februari 2024</div>
                                                            <div class="editable mb-2 font-weight-bold" style="font-size: 14px;">Pukul : 09.00 WIB s.d. Selesai</div>
                                                            <div class="color-accent editable font-weight-bold" style="font-size: 14.4px;">Rumah Lombok Bandung</div>
                                                            <div class="editable" style="font-size: 12px;">Komp. Permata Biru Blok I No. 69H RT 04 RW 15<br>Cinunuk Kec. Cileunyi Kab. Bandung</div>
                                                        </div>
                                                    </div>
                                                    <div class="text-center mb-3">
                                                        <div class="editable color-accent h4 mb-2 animate__animated animate__fadeInDown animate__slower font-accent" style="font-size: 16px;">Undangan</div>
                                                        <div class="mb-4 d-flex flex-row justify-content-center align-items-center animate__animated animate__zoomIn animate__slower">
                                                            <div class="editable" style="font-size: 14.4px; width: 100px;">Kamis</div>
                                                            <div class="px-3" style="border-left: 2px solid var(--inv-accent); border-right: 2px solid var(--inv-accent);">
                                                                <div class="editable" style="font-size: 50px; line-height: 1;">15</div>
                                                            </div>
                                                            <div class="editable" style="font-size: 14.4px; width: 100px;">FEB 2024</div>
                                                        </div>
                                                        <div class="editable animate__animated animate__fadeInDown animate__slower" style="font-size: 14.4px;">Pukul 10.0 s.d. 16.00 WIB</div>
                                                        <div class="color-accent editable animate__animated animate__fadeInDown animate__slower font-weight-bold" style="font-size: 16px;">Rumah Lombok Bandung</div>
                                                        <div class="editable animate__animated animate__fadeInDown animate__slower" style="font-size: 14.4px;">Komp. Permata Biru Blok I No. 69H RT 04 RW 15<br>Cinunuk Kec. Cileunyi Kab. Bandung</div>
                                                    </div>
                                                    <div data-datetime="2024-02-15T08:00" class="countdown-wrapper d-flex flex-column animate__animated animate__fadeInUp animate__slower">
                                                        <div class="countdown text-center">
                                                            <div class="countdown-item day">
                                                                <div class="number">00</div>
                                                                <div class="text editable">Hari</div>
                                                            </div>
                                                            <div class="countdown-item hour">
                                                                <div class="number">00</div>
                                                                <div class="text editable">Jam</div>
                                                            </div>
                                                            <div class="countdown-item minute">
                                                                <div class="number">00</div>
                                                                <div class="text editable">Menit</div>
                                                            </div>
                                                            <div class="countdown-item second">
                                                                <div class="number">00</div>
                                                                <div class="text editable">Detik</div>
                                                            </div>
                                                        </div> <button class="btn-countdown btn btn-sm btn-pilled btn-accent mt-2">Atur Countdown</button>
                                                    </div>
                                                    <div class="text-center"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="d-flex justify-content-center align-items-center" style="height: 100%;">
                                                <div style="width: 100%;">
                                                    <div>
                                                        <div class="animate__animated animate__fadeInDown animate__slow" style="width: 100%; margin: auto auto 20px; border-radius: 10px; overflow: hidden; padding-bottom: 100%; position: relative;"><iframe width="100%" height="100%" allowfullscreen="allowfullscreen" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCpV55KNPo55TuxnDFd_dR3MD0luBrN1Gc&amp;zoom=17&amp;q=-6.907865200000001,107.6192617" class="maps-embed" style="border: 0px; position: absolute;"></iframe></div> <button class="btn-maps btn btn-sm btn-pilled btn-block btn-accent mt-1 mb-4">Edit Denah Lokasi</button>
                                                        <div class="text-center animate__animated animate__fadeInUp animate__slow">
                                                            <div class="color-accent editable font-weight-bold" style="font-size: 14px;">Rumah Lombok Bandung</div>
                                                            <div class="editable mb-3" style="font-size: 14px;">Komp. Permata Biru Blok I No. 69H RT 04 RW 15<br>Cinunuk Kec. Cileunyi Kab. Bandung</div><a href="https://www.google.com/maps/place/?q=-6.907865200000001,107.6192617" target="_blank" rel="noreferrer noopener" class="btn-maps-link mx-auto btn btn-primary rounded-pill animate__animated animate__fadeInUp animate__slow" style="gap: 8px; max-width: 200px;">
                                                                Petunjuk Ke Lokasi</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="d-flex justify-content-center align-items-center" style="height: 100%;">
                                                <div style="width: 100%;">
                                                    <div class="text-center">
                                                        <div class="editable font-latin color-accent h4 mb-4 animate__animated animate__fadeInDown animate__slower">Do'a Untuk Pengantin</div>
                                                        <div class="editable mb-4 animate__animated animate__fadeInUp animate__slower">"Semoga Allah memberkahimu di waktu bahagia dan memberkahimu di waktu susah, dan mengumpulkan kalian berdua dalam kebaikan"<br><br>[HR. Abu Daud]</div>
                                                        <div class="editable mb-4 animate__animated animate__fadeInUp animate__slower">Tekan tombol dibawah ini untuk mengirim ucapan dan konfirmasi kehadiran</div><button class="btn-rsvp btn btn-primary rounded-pill mb-4 animate__animated animate__fadeInUp animate__slow">Konfirmasi &amp; Kirim Ucapan</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="d-flex justify-content-center align-items-center" style="height: 100%;">
                                                <div class="text-center" style="width: 100%;">
                                                    <div class="font-latin color-accent h4 mb-2 editable animate__animated animate__fadeInDown animate__slower" style="font-size: 28.8px;">Tanda Kasih</div>
                                                    <div class="editable mb-4 animate__animated animate__fadeInDown animate__slower" style="font-size: 14.4px;">Terima kasih telah menambah semangat kegembiraan pernikahan kami dengan kehadiran dan hadiah indah Anda.</div>
                                                    <div style="display: flex; gap: 8px;"><button class="btn-gift btn btn-block btn-primary rounded-pill animate__animated animate__fadeInUp animate__slow" style="max-width: 150px; margin: auto; font-size: 14.4px;">🎁 Cashless</button></div>
                                                    <div class="gift-container mt-3 p-4 rounded animate__animated animate__zoomIn animate__slow" style="display: none;">
                                                        <div class="d-flex">
                                                            <div class="mx-auto">
                                                                <div class="d-flex align-items-center mb-3">
                                                                    <div class="image-editable" style="width: 80px; overflow: hidden;"><img src="https://assets.satumomen.com/images/no-image.jpg" alt="no-image.jpg" style="width: 100%; height: 100%; object-fit: contain;"></div>
                                                                    <div class="text-left pl-2">
                                                                        <div class="editable account-number font-weight-bold h5 mb-0" style="display: inline;">12345678</div><button type="button" class="btn btn-sm btn-primary ml-2 mb-1 animate__animated animate__zoomIn animate__slow delay-5" data-text="12345678" onclick="copyText(event)" style="font-family: sans-serif; border-radius: 4px; line-height: 1">Salin</button>
                                                                        <div class="editable" style="font-size: 14.4px;">BCA : Atas Nama Rekening</div>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center">
                                                                    <div class="image-editable" style="width: 80px; overflow: hidden;"><img src="https://assets.satumomen.com/images/no-image.jpg" alt="no-image.jpg" style="width: 100%; height: 100%; object-fit: contain;"></div>
                                                                    <div class="text-left pl-2">
                                                                        <div class="editable account-number font-weight-bold h5 mb-0" style="display: inline;">12345678</div><button type="button" class="btn btn-sm btn-primary ml-2 mb-1 animate__animated animate__zoomIn animate__slow delay-5" data-text="12345678" onclick="copyText(event)" style="font-family: sans-serif; border-radius: 4px; line-height: 1">Salin</button>
                                                                        <div class="editable" style="font-size: 14.4px;">BCA : Atas Nama</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="satumomen_slide" style="display: none;">
                                        <div class="container-mobile" style="background-image: url(&quot;https://satumomen.com/themes/feminime-javanese/bg.jpg&quot;);">
                                            <div class="frame"><img src="/themes/feminime-javanese/tl.webp" alt="frame" class="frame-tl animate__animated animate__fadeInTopLeft animate__slower"> <img src="/themes/feminime-javanese/tr.webp" alt="frame" class="frame-tr animate__animated animate__fadeInTopRight animate__slower"> <img src="/themes/feminime-javanese/bl.webp" alt="frame" class="frame-bl animate__animated animate__fadeInBottomLeft animate__slower"> <img src="/themes/feminime-javanese/br.webp" alt="frame" class="frame-br animate__animated animate__fadeInBottomRight animate__slower"></div>
                                            <div class="watermark d-flex flex-column" style="height: 100%;">
                                                <div class="mt-auto" style="width: 100%;">
                                                    <div class="text-center">
                                                        <div class="editable mb-2 animate__animated animate__fadeInDown animate__slower" style="font-size: 14px;">Merupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu/ Saudara/I berkenan hadir untuk memberikan do’a restu kepada putri kami.</div>
                                                        <div class="color-accent editable mb-3 animate__animated animate__fadeInDown animate__slower" style="font-size: 14px;">Wassalamu'alaikum Warahmatullahi Wabarakatuh</div>
                                                        <div class="mb-2 editable animate__animated animate__fadeInDown animate__slow" style="font-size: 14px;">Kami yang berbahagia<br></div>
                                                        <div class="text-center d-flex align-items-center justify-content-center animate__animated animate__fadeInDown animate__slow" style="gap: 14px; line-height: 1.2;">
                                                            <div>
                                                                <div class="editable" style="text-decoration: underline; font-size: 10px;">Kel. Bpk. Dr. H. Rusman Nurdin, S.Sen., M.Sn.</div>
                                                                <div class="editable" style="font-size: 10px;">Ibu Hj. Lilis Sriyeti, BA.</div>
                                                            </div>
                                                            <div>
                                                                <div class="editable" style="text-decoration: underline; font-size: 10px;">Kel. Bpk. Supriatna (Alm)</div>
                                                                <div class="editable" style="font-size: 10px;">Ibu Eti Rohayati</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="watermark-placeholder text-center mb-auto mb-5 pb-5">
                                                    <div id="waterMark" class="mt-5" style="display: inherit;">
                                                        <div class="wm-music mt-3 text-center animate__animated animate__fadeInUp animate__slower animate__delay-1s" style="font-size: 60%;">
                                                            <div style="opacity: 0.5;"><strong>Music:</strong></div>
                                                            <div style="opacity: 0.5;">REFF Nyoman Paul Andi Rianto The Way You Look At Me</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div id="smMenu" class="satumomen_menu">
                            <ul class="satumomen_menu_list" style="transform: translateX(0px);">
                                <li class="satumomen_menu_item active" style="max-width: 82.8px;"><i class="icon ph-fill ph-envelope" style="color: currentcolor;"></i> <span>Opening</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><i class="icon ph-fill ph-star-and-crescent" style="color: currentcolor;"></i> <span>Quotes</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><svg width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path opacity=".4" d="M11.776 21.837a36.258 36.258 0 0 1-6.328-4.957 12.668 12.668 0 0 1-3.03-4.805C1.278 8.535 2.603 4.49 6.3 3.288A6.282 6.282 0 0 1 12.007 4.3a6.291 6.291 0 0 1 5.706-1.012c3.697 1.201 5.03 5.247 3.893 8.787a12.67 12.67 0 0 1-3.013 4.805 36.58 36.58 0 0 1-6.328 4.957l-.25.163-.24-.163Z" fill="currentColor"></path>
                                        <path d="m12.01 22-.234-.163a36.316 36.316 0 0 1-6.337-4.957 12.667 12.667 0 0 1-3.048-4.805c-1.13-3.54.195-7.586 3.892-8.787a6.296 6.296 0 0 1 5.728 1.023V22ZM18.23 10a.719.719 0 0 1-.517-.278.818.818 0 0 1-.167-.592c.022-.702-.378-1.341-.994-1.59-.391-.107-.628-.53-.53-.948.093-.41.477-.666.864-.573a.384.384 0 0 1 .138.052c1.236.476 2.036 1.755 1.973 3.155a.808.808 0 0 1-.23.56.708.708 0 0 1-.537.213Z" fill="currentColor"></path>
                                    </svg> <span>Mempelai</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><i class="icon ph-fill ph-clock" style="color: currentcolor;"></i> <span>Acara</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><svg width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.532 2.937a6.89 6.89 0 0 1 7.034.058C17.71 4.327 19.012 6.705 19 9.26c-.05 2.54-1.447 4.929-3.193 6.775a18.727 18.727 0 0 1-3.358 2.82 1.173 1.173 0 0 1-.408.144.82.82 0 0 1-.39-.119 18.515 18.515 0 0 1-4.839-4.547A9.28 9.28 0 0 1 5 9.134c-.001-2.562 1.347-4.928 3.532-6.197Zm1.262 7.258a2.378 2.378 0 0 0 2.198 1.497 2.339 2.339 0 0 0 1.683-.701c.446-.454.696-1.07.694-1.713a2.423 2.423 0 0 0-1.462-2.243 2.346 2.346 0 0 0-2.594.52 2.455 2.455 0 0 0-.519 2.64Z" fill="currentColor"></path>
                                        <ellipse opacity=".4" cx="12" cy="21" rx="5" ry="1" fill="currentColor"></ellipse>
                                    </svg> <span>Maps</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><i class="icon ph-fill ph-chat-circle-text" style="color: currentcolor;"></i> <span>RSVP</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><i class="icon ph-fill ph-gift" style="color: currentcolor;"></i> <span>Gift</span></li>
                                <li class="satumomen_menu_item" style="max-width: 82.8px;"><i class="icon ph-fill ph-mosque" style="color: currentcolor;"></i> <span>Thanks</span></li>
                            </ul>
                        </div>
                        <div class="floating-action d-flex align-items-end flex-column"><button id="btnQrModal" onclick="if (!window.__cfRLUnblockHandlers) return false; showModal(qrModal)" class="btn btn-float"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256">
                                    <rect x="40" y="40" width="80" height="80" rx="16"></rect>
                                    <rect x="40" y="136" width="80" height="80" rx="16"></rect>
                                    <rect x="136" y="40" width="80" height="80" rx="16"></rect>
                                    <path d="M144,184a8,8,0,0,0,8-8V144a8,8,0,0,0-16,0v32A8,8,0,0,0,144,184Z"></path>
                                    <path d="M208,152H184v-8a8,8,0,0,0-16,0v56H144a8,8,0,0,0,0,16h32a8,8,0,0,0,8-8V168h24a8,8,0,0,0,0-16Z"></path>
                                    <path d="M208,184a8,8,0,0,0-8,8v16a8,8,0,0,0,16,0V192A8,8,0,0,0,208,184Z"></path>
                                </svg></button> <button id="btnMusic" onclick="if (!window.__cfRLUnblockHandlers) return false; playMusic()" class="btn btn-float playing"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256" class="play">
                                    <path d="M184,152V104a8,8,0,0,1,16,0v48a8,8,0,0,1-16,0Zm40-72a8,8,0,0,0-8,8v80a8,8,0,0,0,16,0V88A8,8,0,0,0,224,80ZM53.92,34.62A8,8,0,1,0,42.08,45.38L73.55,80H32A16,16,0,0,0,16,96v64a16,16,0,0,0,16,16H77.25l69.84,54.31A8,8,0,0,0,160,224V175.09l42.08,46.29a8,8,0,1,0,11.84-10.76Zm92.16,77.59A8,8,0,0,0,160,106.83V32a8,8,0,0,0-12.91-6.31l-39.85,31a8,8,0,0,0-1,11.7Z"></path>
                                </svg> <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256" class="pause">
                                    <path d="M160,32V224a8,8,0,0,1-12.91,6.31L77.25,176H32a16,16,0,0,1-16-16V96A16,16,0,0,1,32,80H77.25l69.84-54.31A8,8,0,0,1,160,32Zm32,64a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V104A8,8,0,0,0,192,96Zm32-16a8,8,0,0,0-8,8v80a8,8,0,0,0,16,0V88A8,8,0,0,0,224,80Z"></path>
                                </svg></button> <button id="btnAutoplay" class="btn btn-float"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256" class="play">
                                    <path d="M128,24A104,104,0,1,0,232,128,104.13,104.13,0,0,0,128,24Zm36.44,110.66-48,32A8.05,8.05,0,0,1,112,168a8,8,0,0,1-8-8V96a8,8,0,0,1,12.44-6.66l48,32a8,8,0,0,1,0,13.32Z"></path>
                                </svg> <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256" class="pause">
                                    <path d="M128,24A104,104,0,1,0,232,128,104.13,104.13,0,0,0,128,24ZM112,160a8,8,0,0,1-16,0V96a8,8,0,0,1,16,0Zm48,0a8,8,0,0,1-16,0V96a8,8,0,0,1,16,0Z"></path>
                                </svg></button></div>
                    </div>
                </div>
            </div>
        </div>
        <div id="lightboxWrapper" class="lightbox-wrapper">
            <div class="lightbox-list"></div> <a href="#" id="lightboxCloseBtn" class="btn-lightbox"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 0 1 1.414 0L10 8.586l4.293-4.293a1 1 0 1 1 1.414 1.414L11.414 10l4.293 4.293a1 1 0 0 1-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 0 1-1.414-1.414L8.586 10 4.293 5.707a1 1 0 0 1 0-1.414z" clip-rule="evenodd"></path>
                </svg></a>
            <div class="lightbox-navigation"><a href="#" id="lightboxPrevBtn" data-index="0" class="lightbox-arrow"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m15 19-7-7 7-7"></path>
                    </svg></a> <a href="#" id="lightboxNextBtn" data-index="0" class="lightbox-arrow"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 5 7 7-7 7"></path>
                    </svg></a></div>
        </div>
        <div id="qrModal" tabindex="-1" role="dialog" aria-labelledby="qrModal" aria-hidden="true" class="modal fade">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content" style="height: 100%;">
                    <div style="width: 100%; aspect-ratio: 16 / 9; background-size: cover; background-position: center center; background-image: url(&quot;/images/no-image.jpg&quot;);"></div>
                    <div class="text-center py-4 px-4">
                        <div>
                            <div class="mx-auto"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180" height="180" viewBox="0 0 180 180">
                                    <rect x="0" y="0" width="180" height="180" fill="#ffffff"></rect>
                                    <g transform="scale(7.2)">
                                        <g transform="translate(0,0)">
                                            <path fill-rule="evenodd" d="M8 0L8 1L9 1L9 2L10 2L10 3L11 3L11 1L13 1L13 0L11 0L11 1L9 1L9 0ZM14 0L14 1L15 1L15 0ZM16 0L16 1L17 1L17 0ZM12 2L12 4L11 4L11 5L10 5L10 4L9 4L9 5L10 5L10 8L9 8L9 6L8 6L8 8L9 8L9 10L8 10L8 11L7 11L7 10L6 10L6 11L5 11L5 8L3 8L3 9L4 9L4 12L5 12L5 13L3 13L3 10L2 10L2 8L0 8L0 11L1 11L1 12L0 12L0 17L1 17L1 15L3 15L3 16L2 16L2 17L7 17L7 16L6 16L6 15L8 15L8 18L9 18L9 20L8 20L8 22L9 22L9 20L10 20L10 23L8 23L8 25L9 25L9 24L10 24L10 23L11 23L11 20L10 20L10 19L12 19L12 21L14 21L14 24L13 24L13 25L15 25L15 22L16 22L16 23L17 23L17 22L19 22L19 21L21 21L21 16L22 16L22 18L24 18L24 19L23 19L23 22L20 22L20 23L18 23L18 25L19 25L19 24L21 24L21 25L22 25L22 24L24 24L24 25L25 25L25 18L24 18L24 16L25 16L25 14L24 14L24 13L25 13L25 10L24 10L24 9L25 9L25 8L24 8L24 9L19 9L19 8L18 8L18 9L19 9L19 10L16 10L16 9L17 9L17 6L16 6L16 8L14 8L14 7L15 7L15 6L14 6L14 5L15 5L15 4L16 4L16 5L17 5L17 3L15 3L15 4L14 4L14 2ZM12 4L12 5L11 5L11 7L12 7L12 9L10 9L10 10L9 10L9 11L10 11L10 10L12 10L12 11L13 11L13 13L11 13L11 12L10 12L10 13L9 13L9 14L8 14L8 12L7 12L7 11L6 11L6 12L7 12L7 13L6 13L6 14L3 14L3 15L4 15L4 16L5 16L5 15L6 15L6 14L8 14L8 15L9 15L9 14L10 14L10 15L11 15L11 14L14 14L14 13L16 13L16 12L17 12L17 13L18 13L18 14L19 14L19 15L20 15L20 16L21 16L21 15L20 15L20 13L21 13L21 14L23 14L23 13L24 13L24 12L21 12L21 10L20 10L20 11L19 11L19 13L18 13L18 11L15 11L15 10L14 10L14 11L13 11L13 10L12 10L12 9L14 9L14 8L13 8L13 7L14 7L14 6L13 6L13 7L12 7L12 5L14 5L14 4ZM6 8L6 9L7 9L7 8ZM22 10L22 11L24 11L24 10ZM14 11L14 12L15 12L15 11ZM1 13L1 14L2 14L2 13ZM16 14L16 16L15 16L15 15L12 15L12 16L9 16L9 17L14 17L14 18L12 18L12 19L13 19L13 20L14 20L14 19L16 19L16 16L18 16L18 15L17 15L17 14ZM23 15L23 16L24 16L24 15ZM14 16L14 17L15 17L15 16ZM17 17L17 20L20 20L20 17ZM18 18L18 19L19 19L19 18ZM12 22L12 23L13 23L13 22ZM21 23L21 24L22 24L22 23ZM16 24L16 25L17 25L17 24ZM0 0L0 7L7 7L7 0ZM1 1L1 6L6 6L6 1ZM2 2L2 5L5 5L5 2ZM18 0L18 7L25 7L25 0ZM19 1L19 6L24 6L24 1ZM20 2L20 5L23 5L23 2ZM0 18L0 25L7 25L7 18ZM1 19L1 24L6 24L6 19ZM2 20L2 23L5 23L5 20Z" fill="#000000"></path>
                                        </g>
                                    </g>
                                </svg>
                                <div style="margin-top: 10px; text-align: center;"></div>
                            </div>
                        </div>
                        <hr style="margin-top: 1rem; margin-bottom: 1rem; border-width: 2px 0px 0px; border-top-style: dashed; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-top-color: rgba(0, 0, 0, 0.1); border-right-color: initial; border-bottom-color: initial; border-left-color: initial; border-image: initial;">
                        <div style="margin-bottom: 10px;">
                            <div style="color: rgb(178, 178, 178);">Nama</div>
                            <div>Nama Tamu</div>
                        </div>
                    </div> <button onclick="if (!window.__cfRLUnblockHandlers) return false; closeModal(qrModal)" type="button" class="btn btn-close"><svg xmlns="http://www.w3.org/2000/svg" height="42px" width="42px" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 18 6M6 6l12 12"></path>
                        </svg></button>
                </div>
            </div>
        </div>
        <div id="rsvpModal" tabindex="-1" role="dialog" aria-labelledby="rsvpModal" class="modal fade">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content p-4" style="height: 100%;">
                    <div class="rsvp-form p-3 d-flex flex-column align-items-center justify-content-center" style="height: 100%;">
                        <div class="mb-3 text-center"><svg xmlns="http://www.w3.org/2000/svg" height="90" width="90" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 18.364A9 9 0 0 0 5.636 5.636m12.728 12.728A9 9 0 0 1 5.636 5.636m12.728 12.728L5.636 5.636"></path>
                            </svg>
                            <h2 class="mb-3 h3 font-weight-bold">Fitur RSVP Belum Diaktifkan</h2>
                            <p>Aktifkan terlebih dahulu agar dapat menampilkan form RSVP. Klik menu RSVP di halaman edit
                                undangan lalu pada bagian pengaturan klik Aktifkan.</p>
                        </div>
                    </div> <button onclick="if (!window.__cfRLUnblockHandlers) return false; closeModal(rsvpModal)" type="button" class="btn btn-close"><svg xmlns="http://www.w3.org/2000/svg" height="42px" width="42px" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 18 6M6 6l12 12"></path>
                        </svg></button>
                </div>
            </div>
        </div>
    </main>
    <!-- illegal -->
    <div id="illegal" class="container-mobile" style="background: #ffffff; z-index: 9999; min-height: 100vh; display: flex; justify-content: center; align-items: center; display: none">
        <div class="modal-body modal-body d-flex flex-column align-items-center">
            <div class="mb-4 text-center">
                <svg width="90" height="90" fill="none">
                    <path d="M36 28.024A18.05 18.05 0 0025.022 39M59.999 28.024A18.05 18.05 0 0170.975 39" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <ellipse cx="37.5" cy="43.5" rx="4.5" ry="7.5" fill="currentColor"></ellipse>
                    <ellipse cx="58.5" cy="43.5" rx="4.5" ry="7.5" fill="currentColor"></ellipse>
                    <path d="M24.673 75.42a9.003 9.003 0 008.879 5.563m-8.88-5.562A8.973 8.973 0 0124 72c0-7.97 9-18 9-18s9 10.03 9 18a9 9 0 01-8.448 8.983m-8.88-5.562C16.919 68.817 12 58.983 12 48c0-19.882 16.118-36 36-36s36 16.118 36 36-16.118 36-36 36a35.877 35.877 0 01-14.448-3.017" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M41.997 71.75A14.94 14.94 0 0148 70.5c2.399 0 4.658.56 6.661 1.556a3 3 0 003.999-4.066 12 12 0 00-10.662-6.49 11.955 11.955 0 00-7.974 3.032c1.11 2.37 1.917 4.876 1.972 7.217z" fill="currentColor"></path>
                </svg>
                <h2 class="mb-3">Jangan Bikin Aku Sedih</h2>
                <p>Kamu didapati mencoba menghapus watermark secara ilegal.</p>
            </div>
        </div>
    </div>
    <!-- end illegal -->

    <!-- not support modal -->
    <div class="modal fade" id="notSupport" tabindex="-1" role="dialog" aria-labelledby="notSupport" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="border-radius: .8rem;">
                <div class="modal-body text-center justify-content-center align-items-center">
                    <h2>Pemberitahuan</h2>
                    <p>Browser yang kamu gunakan mungkin kurang kompatibel. Beberapa fungsi undangan ini mungkin tidak dapat berjalan dengan baik. Kami merekomendasikan Chrome. Klik tombol dibawah ini untuk mendownload.</p>
                    <div class="d-flex justify-content-center">
                        <a href="https://apps.apple.com/id/app/google-chrome/id535886823" class="btn p-1" target="_BLANK">
                            <img src="/images/btn_app_store.png" alt="AppStore" height="40px">
                        </a>
                        <a href="https://play.google.com/store/apps/details?id=com.android.chrome&amp;hl=in&amp;gl=US" class="btn p-1" target="_BLANK">
                            <img src="/images/btn_play_store.png" alt="PlayStore" height="40px">
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-outline-secondary btn-block rounded-pill" onclick="if (!window.__cfRLUnblockHandlers) return false; closeModal(notSupport)">Tetap Akses</button>
                </div>
            </div>
        </div>
    </div>
    <!-- not support modal -->

    <!-- start script -->
    <script src="https://satumomen.com/js/theme-app.js?v=241207" type="text/javascript"></script>
    <script src="https://satumomen.com/themes/themesv2.js?v=241207" type="text/javascript"></script>
    <script type="text/javascript">
        var notSupport = document.getElementById('notSupport');

        function checkBrowser() {
            if (navigator.userAgent.indexOf("UCBrowser") != -1 || navigator.userAgent.indexOf("MiuiBrowser") != -1 || navigator.userAgent.indexOf("OppoBrowser") != -1) {
                showModal(notSupport);
                if (loader) {
                    loader.style.display = "none";
                }
            }
        }
        checkBrowser()
    </script>
    <!-- end script -->
    <script type="text/javascript">

    </script>
    <script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon="{&quot;rayId&quot;:&quot;904d89380e2efd0b&quot;,&quot;serverTiming&quot;:{&quot;name&quot;:{&quot;cfExtPri&quot;:true,&quot;cfL4&quot;:true,&quot;cfSpeedBrain&quot;:true,&quot;cfCacheStatus&quot;:true}},&quot;version&quot;:&quot;2025.1.0&quot;,&quot;token&quot;:&quot;bb94421b81454f668eb9cf5cf8e9f0cb&quot;}" crossorigin="anonymous"></script>


</body>

</html>