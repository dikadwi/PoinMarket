<!-- Card -->
<div class="row">
    <?php
    // Cari data transaksi berdasarkan kata kunci
    if (isset($_GET['search'])) {
        $search = strtolower($_GET['search']);  // Mengonversi kata kunci pencarian menjadi huruf kecil
        $transaksi = array_filter($transaksi, function ($data) use ($search) {
            // Mengonversi data transaksi dan search menjadi huruf kecil
            return strpos(strtolower(strval($data['id_transaksi'])), $search) !== false ||
                strpos(strtolower(strval($data['nama_transaksi'])), $search) !== false ||
                strpos(strtolower(strval($data['poin_digunakan'])), $search) !== false;
        });
    }


    // Tampilkan card untuk setiap transaksi
    if (empty($transaksi) || (isset($creator) && empty(array_filter($transaksi, function ($t) use ($creator) {
        return $t['creator'] == $creator;
    })))) : ?>
        <div class="col-12 text-center">
            <h5 class="text-muted"><strong>Tidak ada data yang tersedia.</strong></h5>
        </div>
    <?php else : ?>
        <?php $i = 1; ?>
        <?php foreach ($transaksi as $t) : ?>
            <?php if (isset($creator) && $t['creator'] != $creator) continue; ?>
            <div class="col-6 col-md-3 d-flex">
                <div class="card flex-fill d-flex flex-column">
                    <!-- Card Header -->
                    <div class="card-header text-center">
                        <h5 class="card-title"><strong><?= $t['nama_transaksi']; ?></strong></h5>
                    </div>

                    <!-- Card Image -->
                    <div class="card-img-container">
                        <img src="<?= base_url('uploads/' . $t['gambar']); ?>"
                            class="card-img-top"
                            alt="Gambar_Item"
                            style="width: 100%; height: auto;">
                    </div>

                    <!-- Card Body -->
                    <div class="card-body">
                        <p class="card-text">
                            <!-- Kategori -->
                            <!-- <strong>Kategori:</strong> <= $t['kode_jenis']; ?><br> -->
                            <!-- Rule Item -->
                            <strong>Rule Item:</strong> <?= $t['detail']; ?><br>
                            <!-- Feedback -->
                            <strong>Feedback:</strong> <?= $t['keterangan']; ?><br>
                            <!-- Poin (Reward, Penalti, atau Harga) -->
                            <!-- Untuk Poin Harga -->
                            <?php if (in_array($t['kode_jenis'], ['102', '103', '105', '106'])) : ?>
                                <strong>
                                    <?php
                                    if ($t['kode_jenis'] == '103') {
                                        echo 'Penalti :';
                                    } else {
                                        echo 'Harga :';
                                    }
                                    ?>
                                </strong> <?= $t['poin_digunakan']; ?> Point <br>
                            <?php endif; ?>
                            <!-- Reward Untuk Kode Jenis 101 dan 105 -->
                            <?php if (in_array($t['kode_jenis'], ['101', '105'])) : ?>
                                <strong>Reward:</strong> <?= $t['poin_diberikan']; ?> Point<br>
                            <?php endif; ?>
                            <?php
                            $status = esc($t['valid']);
                            if ($status == 'Yes') {
                                $statusText = 'Tervalidasi';
                                $btnClass = 'btn-success';
                            } elseif ($status == 'No') {
                                $statusText = 'Tidak Tervalidasi';
                                $btnClass = 'btn-danger';
                            } elseif ($status == 'Wait') {
                                $statusText = 'Menunggu Validasi';
                                $btnClass = 'btn-warning';
                            } else {
                                $statusText = $status; // Jika status tidak sesuai dengan Yes atau No
                                $btnClass = 'btn-secondary';
                            }
                            ?>
                            <strong>Status :</strong>
                            <button type="button" class="btn btn-sm <?= $btnClass ?> d-inline-block mb-2">
                                <?= $statusText ?>
                            </button><br>
                            <?php
                            $itemstatus = esc($t['status']);
                            if ($itemstatus == 'Yes') {
                                $itemstatusText = 'Aktif';
                                $btnClass = 'btn-success';
                            } else {
                                $itemstatusText = 'Tidak Aktif';
                                $btnItemClass = 'btn-danger';
                                $btnClass = 'btn-danger';
                            }
                            ?>
                            <i class="fas fa-shopping-cart"></i>
                            <strong>:</strong>
                            <button type="button" class="btn btn-sm <?= $btnClass ?> d-inline-block">
                                <?= $itemstatusText ?>
                            </button>
                        </p>
                    </div>
                    <div class="d-flex justify-content-between mb-2 mx-3">
                        <!-- Creator -->
                        <!-- <button type="button" class="btn btn-info btn-block d-flex flex-column align-items-center">
                    <i class="fas fa-user"></i>
                    <span class="d-none d-md-inline"><?= $t['creator']; ?></span>
                </button> -->
                        <button type="button" class="btn btn-pembuat btn-primary d-inline-block text-center opacity-50" data-toggle="modal" data-target="">
                            <i class="fas fa-user"></i> <!-- Ikon di atas teks -->
                            <span> <?= $t['creator']; ?></span> <!-- Teks di bawah ikon -->
                        </button>
                    </div>
                    <!-- Card Footer (Tombol Aksi) -->
                    <div class="card-footer">
                        <div class="row d-flex justify-content-center">
                            <!-- Tombol Detail -->
                            <div class="col-6 col-md-3 mb-2 mb-md-0">
                                <button type="button" class="btn btn-info btn-block d-flex flex-column align-items-center" data-toggle="modal" data-target="#modalDetail<?= esc($t['id_transaksi']) ?>">
                                    <i class="fas fa-eye"></i>
                                    <span class="d-none d-md-inline"> Detail</span>
                                </button>
                            </div>
                            <!-- Tombol Edit (Hanya untuk Admin & Dosen) -->
                            <?php if (in_groups('superadmin') || ($t['kode_jenis'] == '103' && in_groups('admin')) || (in_groups('dosen') && $t['kode_jenis'] != '103')) : ?>
                                <div class="col-6 col-md-3 mb-2 mb-md-0">
                                    <button type="button" class="btn btn-warning btn-block d-flex flex-column align-items-center" data-toggle="modal" data-target="#modalEdit<?= esc($t['id_transaksi']) ?>">
                                        <i class="fas fa-edit"></i>
                                        <span class="d-none d-md-inline"> Edit</span>
                                    </button>
                                </div>
                            <?php endif ?>
                            <!-- Tombol Validasi -->
                            <?php if (in_groups(['superadmin', 'admin'])) : ?>
                                <div class="col-6 col-md-3 mb-2 mb-md-0">
                                    <button type="button" class="btn btn-secondary btn-block d-flex flex-column align-items-center" data-toggle="modal" data-target="#modalValidasi<?= esc($t['id_transaksi']) ?>">
                                        <i class="fas fa-check-circle"></i> <!-- Ikon di atas teks -->
                                        <span class="d-none d-md-inline">Validasi</span> <!-- Teks di bawah ikon -->
                                    </button>
                                </div>
                            <?php endif; ?>
                            <!-- Tombol Hapus (Hanya untuk SuperAdmin & Admin) -->
                            <?php if (in_groups('superadmin') || ($t['kode_jenis'] == '103' && in_groups('admin')) || (in_groups('dosen') && $t['kode_jenis'] != '103')) : ?>
                                <div class="col-6 col-md-3 mb-2 mb-md-0">
                                    <button href="/Jenis_Transaksi/delete/<?= $t['id_transaksi']; ?>" class="btn btn-danger btn-hapus btn-block d-flex flex-column align-items-center">
                                        <i class="fas fa-trash"></i>
                                        <span class="d-none d-md-inline"> Hapus</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Modal box Detail -->
<?php foreach ($transaksi as $t) : ?>
    <div class="modal fade" id="modalDetail<?php echo $t['id_transaksi']; ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel"><?= $t['nama_transaksi']; ?> </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="max-height: 450px; overflow-y: auto;">
                    <div class="col-lg-13">
                        <div class="row g-0">
                            <div class="col-md-12">
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <h5 class="card-title"><b>Id Transaksi :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $t['id_transaksi']; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>Nama Item :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $t['nama_transaksi']; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>Rule Item :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $t['detail']; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>Feedback :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $t['keterangan']; ?></h4>
                                        </li>
                                        <!-- Untuk Poin Harga -->
                                        <?php if (in_array($t['kode_jenis'], ['102', '103', '105', '106'])) : ?>
                                            <h5 class="card-title"><b>
                                                    <?php
                                                    if ($t['kode_jenis'] == '103') {
                                                        echo 'Penalti :';
                                                    } else {
                                                        echo 'Harga :';
                                                    }
                                                    ?>
                                                </b></h5>
                                            <li class="list-group-item">
                                                <h4> <?= $t['poin_digunakan']; ?> Point </h4>
                                            </li>
                                        <?php endif; ?>
                                        <!-- Reward Untuk Kode Jenis 101 dan 105 -->
                                        <?php if (in_array($t['kode_jenis'], ['101', '105'])) : ?>
                                            <h5 class="card-title"><b>Reward :</b></h5>
                                            <li class="list-group-item">
                                                <h4> <?= $t['poin_diberikan']; ?> Point</h4>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

<?php endforeach; ?>

<!--Data Modal Box Edit Data-->
<?php foreach ($transaksi as $t) : ?>
    <div class="modal fade" id="modalEdit<?php echo $t['id_transaksi']; ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Edit <?= $title; ?> </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body" style="max-height: 450px; overflow-y: auto;">
                    <form action="/Jenis_Transaksi/update_Jenis/<?= $t['id_transaksi']; ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group ">
                            <label for="id" class="col-form-label">Id Transaksi</label>
                            <input type="number" class="form-control" id="id" name="id" value="<?php echo $t['id_transaksi'] ?>" required readonly>
                        </div>
                        <div class="form-group ">
                            <label for="nama_transaksi" class="col-form-label">Nama Item</label>
                            <input type="text" class="form-control" id="nama_transaksi" name="nama_transaksi" value="<?php echo $t['nama_transaksi'] ?>" required oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')">
                        </div>
                        <div class="form-group ">
                            <label for="detail" class="col-form-label">Rule Item</label>
                            <input type="text" class="form-control" id="detail" name="detail" value="<?php echo $t['detail'] ?>" required oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')">
                        </div>
                        <div class="form-group ">
                            <label for="keterangan" class="col-form-label">Feedback</label>
                            <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?php echo $t['keterangan'] ?>" required oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')">
                        </div>
                        <!-- <div class="form-group ">
                            <label for="poin_digunakan" class="col-form-label">Point</label>
                            <input type="number" class="form-control" id="poin_digunakan" name="poin_digunakan" value="<?php echo $t['poin_digunakan'] ?>" required oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')">
                        </div> -->
                        <!-- Menampilkan poin berdasarkan kode_jenis -->
                        <?php if (in_array($t['kode_jenis'], [102, 103, 105, 106])): ?>
                            <div class="form-group">
                                <label for="poin_digunakan" class="col-form-label">Poin Harga</label>
                                <input type="number" class="form-control" id="poin_digunakan" name="poin_digunakan" value="<?php echo $t['poin_digunakan']; ?>" required>
                            </div>
                        <?php endif; ?>
                        <?php if (in_array($t['kode_jenis'], [101, 105])): ?>
                            <div class="form-group">
                                <label for="poin_diberikan" class="col-form-label">Poin Reward</label>
                                <input type="number" class="form-control" id="poin_diberikan" name="poin_diberikan" value="<?php echo isset($t['poin_diberikan']) ? $t['poin_diberikan'] : ''; ?>" required>
                            </div>
                        <?php endif; ?>
                        <div class="form-group ">
                            <label for="gambar" class="col-form-label">Gambar</label>
                            <img src="<?= base_url('uploads/' . $t['gambar']); ?>" alt="Gambar" width="100" height="100">
                            <input type="hidden" name="gambar_lama" value="<?= $t['gambar']; ?>">
                            <input type="file" class="form-control" id="gambar" name="gambar">
                        </div>
                        <?php if (in_groups(['superadmin'])) : ?>
                            <div class="form-group ">
                                <label for="creator" class="col-form-label">Creator</label>
                                <input type="text" class="form-control" id="creator" name="creator" value="<?php echo $t['creator'] ?>">
                            </div>
                        <?php else : ?>
                            <input type="hidden" name="creator" value="<?php echo $t['creator'] ?>">
                        <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                </div>
            </div>
            </form>
        </div>
    </div>
<?php endforeach ?>

<!-- Modal Validasi -->
<?php foreach ($transaksi as $t) : ?>
    <div class="modal fade" id="modalValidasi<?= esc($t['id_transaksi']) ?>" tabindex="-1" role="dialog" aria-labelledby="modalEditLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditLabel">Validasi Item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('/Marketplace/validasi') ?>" method="post">
                        <input type="hidden" name="id_transaksi" value="<?= esc($t['id_transaksi']) ?>">

                        <div class="form-group">
                            <label for="nama_transaksi">Nama Item</label>
                            <input type="text" class="form-control" id="nama_transaksi" name="nama_transaksi" value="<?= esc($t['nama_transaksi']) ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="detail">Rule Item</label>
                            <input type="text" class="form-control" id="detail" name="detail" value="<?= esc($t['detail']) ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Feedback</label>
                            <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?= esc($t['keterangan']) ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="poin_digunakan">Point Harga</label>
                            <input type="number" class="form-control" id="poin_digunakan" name="poin_digunakan" value="<?= esc($t['poin_digunakan']) ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="valid">Status Validasi</label>
                            <select class="form-control" id="valid" name="valid">
                                <option value="Validasi" <?= ($t['valid'] == 'Validasi') ? 'selected' : '' ?>>Validasi</option>
                                <option value="Tidak" <?= ($t['valid'] == 'Tidak') ? 'selected' : '' ?>>Tidak</option>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">Validasi</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach ?>