<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title; ?></title>

    <link rel="shortcut icon" type="image/png" href="/fafavicon.ico">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/summernote/summernote-bs4.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/template/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <link href="<?= base_url() ?>/sweetalert2/package/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .modal-content {
            border-radius: 20px !important;
            overflow: hidden;
            /* Pastikan header tidak keluar dari border-radius */
        }

        /* 
        .modal-header.bg-success {
            background-color: rgba(59, 169, 85, 0.9) !important;
        } */

        /* Mengatur SwallAlert */
        .swal2-popup {
            /* font-size: 1.6rem !important; */
            /* height: auto; */
            /* Menyesuaikan tinggi dengan konten */
            /* width: auto; */
            /* Menentukan lebar popup */
            font-size: 20px;
            /* Mengatur ukuran font */
        }

        /* Mengatur Legend untuk Donuts */
        #legend {
            display: flex;
            /* Gunakan flexbox untuk mengatur elemen secara horizontal */
            flex-wrap: wrap;
            /* Pindah ke baris baru jika konten tidak cukup */
            gap: 10px;
            /* Jarak antar item dalam legend */
            justify-content: center;
            /* Pusatkan konten secara horizontal */
            align-items: center;
            /* Pusatkan konten secara vertikal */
            border: 1px solid #ccc;
            /* Tambahkan border jika diperlukan */
            padding: 10px;
            /* Atur padding jika diperlukan */
        }

        .legend-item {
            display: flex;
            /* Gunakan flexbox untuk mengatur elemen secara horizontal */
            align-items: center;
            /* Pusatkan konten secara vertikal */
        }

        .legend-color {
            width: 20px;
            /* Atur lebar warna */
            height: 10px;
            /* Atur tinggi warna */
            margin-right: 5px;
            /* Jarak antara warna dan teks */
        }

        /* Mengatur SmallBox */
        .small-box .icon {
            font-size: 36px;
            transition: font-size 0.3s ease-in-out;
        }

        .small-box .icon:hover {
            font-size: 24px;
        }

        @media (max-width: 768px) {
            .small-box .icon {
                font-size: 24px;
            }
        }

        @media (max-width: 768px) {
            .icon {
                display: block;
            }
        }

        @media (max-width: 576px) {
            .small-box .icon {
                font-size: 18px;
            }
        }

        @media (max-width: 480px) {
            .small-box .icon {
                font-size: 14px;
            }
        }

        /* Mengatur Small box-b */
        .small-box.b {
            height: 500px;
            /* Atur tinggi box */
            overflow-y: auto;
            /* Tambahkan scrollbar jika isi box melebihi tinggi */
        }

        .small-box.b canvas {
            width: 100% !important;
            /* Atur lebar grafik */
            height: 400px !important;
            /* Atur tinggi grafik */
        }

        .small-box.b table {
            width: 100% !important;
            /* Atur lebar tabel */
            height: 400px !important;
            /* Atur tinggi tabel */
            overflow-y: auto;
            /* Tambahkan scrollbar jika isi tabel melebihi tinggi */
        }

        /* Mengatur Sticky header */
        .sticky-header {
            position: sticky;
            top: 0;
            background-color: #fff;
            padding: 10px;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Optional: Add a shadow for better readability when scrolled */
        .fixed-header {
            position: relative;
        }

        /* CSS untuk mengatur tinggi baris pada tabel dengan kelas 'table_mahasiswa' */
        .table tr {
            height: 50px;
            /* Atur tinggi baris sesuai kebutuhan */
        }

        .table td,
        .table th {
            padding: 4px;
            /* Atur padding untuk mengurangi ruang di dalam sel */
            text-align: center;
            vertical-align: middle;
        }

        .select option {
            font-style: normal;
        }

        @media (max-width: 768px) {
            .small-box {
                margin-bottom: 20px;
                /* Menambahkan jarak antar kotak */
            }

            h1 {
                font-size: 1.5rem;
                /* Mengurangi ukuran font untuk judul */
            }

            .table {
                font-size: 0.9rem;
                /* Mengurangi ukuran font tabel */
            }
        }

        @media (max-width: 768px) {
            .navbar-nav .nav-link .nav-icon {
                display: inline;
            }

            .main-header .navbar-nav .nav-item {
                flex: 1 1 auto;
                text-align: center;
            }

            .navbar-nav .nav-link span {
                display: none;
                /* Sembunyikan teks */
            }

        }

        @media (max-width: 768px) {
            .main-header .navbar-nav .nav-item {
                flex: 1 1 100%;
                margin-bottom: 10px;
            }

            .main-header .navbar-nav .nav-link {
                font-size: 14px;
                padding: 5px 10px;
            }
        }
    </style>
    </script>
</head>


<body class="hold-transition sidebar-mini sidebar-closed sidebar-collapse layout-fixed layout-navbar-fixed">
    <div class="wrapper">


        <!-- Navbar -->
        <?= $this->include('PoinMarket_Admin/Template/topmenu'); ?>
        <!-- /.navbar -->

        <!-- Sidemenu -->
        <?= $this->include('PoinMarket_Admin/Template/sidemenu'); ?>
        <!-- /.Sidemenu -->

        <!-- <div class="content-wrapper"> -->
        <!-- Main Content -->
        <?= $this->renderSection('content'); ?>
        <!-- /.Main Content -->
        <!-- </div> -->

        <!-- Footer -->
        <?= $this->include('PoinMarket_Admin/Template/footer'); ?>
        <!-- /.Footer -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->

    </div>
    <!-- ./wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url() ?>/template/plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?= base_url() ?>/template/plugins/jquery-ui/jquery-ui.min.js"></script>
    <script src="<?= base_url(); ?>/template/plugins/jquery/jquery_migrate.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="<?= base_url() ?>/template/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- ChartJS -->
    <script src="<?= base_url() ?>/template/plugins/chart.js/Chart.min.js"></script>
    <!-- Sparkline -->
    <script src="<?= base_url() ?>/template/plugins/sparklines/sparkline.js"></script>
    <!-- JQVMap -->
    <script src="<?= base_url() ?>/template/plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="<?= base_url() ?>/template/plugins/jquery-knob/jquery.knob.min.js"></script>
    <!-- daterangepicker -->
    <script src="<?= base_url() ?>/template/plugins/moment/moment.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="<?= base_url() ?>/template/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="<?= base_url() ?>/template/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="<?= base_url() ?>/template/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?= base_url() ?>/template/dist/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="<?= base_url() ?>/template/dist/js/demo.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="<?= base_url() ?>/template/dist/js/pages/dashboard.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="<?= base_url() ?>/template/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/jszip/jszip.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="<?= base_url() ?>/template/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?= base_url() ?>/js/script.js"></script>
    <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script>

    <!-- Render section scripts jika ada -->
    <?= $this->renderSection('scripts') ?>

    <script>
        <?php if (session()->getFlashdata('message')): ?>
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: '<?= session()->getFlashdata('message'); ?>',
                showConfirmButton: false,
                timer: 1500
            });
        <?php endif; ?>

        <?php if (session()->has("sukses")) : ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                html: '<?= session("sukses") ?>', //merender pesan sebagai HTML
                showConfirmButton: false,
                timer: 1300
            })
        <?php endif; ?>

        <?php if (session()->has("validasi")) : ?>
            Swal.fire({
                icon: 'info',
                title: 'Menunggu Validasi',
                text: '<?= session("validasi") ?>',
                showConfirmButton: false,
                timer: 1300

            })
        <?php endif; ?>

        <?php if (session()->has("gagal")) : ?>
            Swal.fire({
                icon: 'warning',
                title: '<?= session("gagal") ?>',
                text: 'Silahkan Tambah Data Baru',
                showConfirmButton: true,

            })
        <?php endif; ?>

        <?php if (session()->has("gagal1")) : ?>
            Swal.fire({
                icon: 'warning',
                title: '<?= session("gagal1") ?>',
                showConfirmButton: true,

            })
        <?php endif; ?>


        $(document).on('click', '.btn-hapus', function(e) {
            e.preventDefault();
            const href = $(this).attr('href');

            Swal.fire({
                title: 'Hapus Data ?',
                text: "Apakah Anda Yakin Ingin Menghapus Data !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batal',

            }).then((result) => {
                if (result.value) {
                    document.location.href = href;
                }
            })
        })
    </script>

</body>

</html>