<?php
// Tentukan jumlah data per halaman
$limit = 10;

// Ambil halaman saat ini dari URL, jika tidak ada, set ke 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Hitung total data
$total_data = count($data_transaksi);

// Hitung total halaman
$total_pages = ceil($total_data / $limit);

// Hitung offset untuk query
$offset = ($page - 1) * $limit;

// Ambil data untuk halaman saat ini
$data_transaksi = array_slice($data_transaksi, $offset, $limit);

// Hitung data yang ditampilkan
$start = $offset + 1; // Data pertama yang ditampilkan
$end = min($offset + $limit, $total_data); // Data terakhir yang ditampilkan
?>

<!-- Tabel -->
<table class="table table-bordered table-striped">
    <thead class="bg-info">
        <tr>
            <th scope="col">No</th>
            <th scope="col">
                <form action="" method="get">
                    <div class="input-group mb-2">
                        <!-- Mengecilkan ukuran dropdown -->
                        <select id="npm" name="npm" onchange="filterNPM(this.value)" class="form-control form-control-sm select font-italic">
                            <option value="" disabled selected class="font-italic">NPM</option>
                            <?php foreach ($npm as $mhs) { ?>
                                <option value="<?php echo $mhs['npm']; ?>"><?php echo $mhs['npm']; ?></option>
                            <?php } ?>
                        </select>
                        <div class="input-group-append">
                            <!-- Mengecilkan ukuran tombol -->
                            <button type="submit" class="btn btn-sm btn-primary">
                                <i class="fas fa-filter"></i>
                            </button>
                        </div>
                    </div>
                </form>
                <!-- Teks 'Validasi' di bawah form filter -->
                <span>NPM</span>
            </th>
            <!-- <th scope="col">Jenis Transaksi</th> -->
            <!-- <th scope="col">Kode Transaksi</th> -->
            <th scope="col">Jenis Transaksi</th>
            <th scope="col">Nama Transaksi</th>
            <!-- <th scope="col">NPM</th> -->
            <th scope="col">Poin Digunakan</th><!-- total point mahasiswa (hasil dari transaksi) -->
            <!-- <th scope="col">Keterangan</th> -->
            <th scope="col">Tanggal Transaksi</th>
            <th scope="col">Validasi</th>
            <th scope="col" colspan="2">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php
        // Urutkan data transaksi berdasarkan tanggal transaksi terbaru
        usort($data_transaksi, function ($a, $b) {
            return strtotime($b['tanggal_transaksi']) - strtotime($a['tanggal_transaksi']);
        });

        $jenis_transaksi_map = [
            '101' => 'Reward',
            '102' => 'Pembelian',
            '103' => 'Punishment',
            '105' => 'Misi Tambahan',
            '106' => 'Konsultasi',
        ];

        // Cari data transaksi berdasarkan kata kunci
        if (isset($_GET['search'])) {
            $search = strtolower($_GET['search']);  // Mengonversi kata kunci pencarian menjadi huruf kecil
            $data_transaksi = array_filter($data_transaksi, function ($data) use ($search, $jenis_transaksi_map) {
                // Menyimpan nama jenis transaksi berdasarkan kode
                $jenis_transaksi_name = isset($jenis_transaksi_map[$data['jenis_transaksi']]) ? $jenis_transaksi_map[$data['jenis_transaksi']] : '';

                // Mengonversi data transaksi dan search menjadi huruf kecil
                return strpos(strtolower(strval($data['npm'])), $search) !== false ||
                    strpos(strtolower($jenis_transaksi_name), $search) !== false ||
                    strpos(strtolower(strval($data['nama_transaksi'])), $search) !== false ||
                    strpos(strtolower(strval($data['poin_digunakan'])), $search) !== false ||
                    strpos(strtolower(strval($data['tanggal_transaksi'])), $search) !== false;
            });
            // Perbarui total data setelah pencarian
            $total_data = count($data_transaksi); // Total data setelah filter

            // Hitung total halaman
            $total_pages = ceil($total_data / $limit); // Total halaman berdasarkan limit

            // Hitung offset untuk query
            $offset = ($page - 1) * $limit; // Offset untuk data yang diambil

            // Ambil data untuk halaman saat ini
            $data_transaksi = array_slice($data_transaksi, $offset, $limit); // Ambil data sesuai offset dan limit

            // Hitung data yang ditampilkan
            $start = $offset + 1; // Data pertama yang ditampilkan
            $end = min($offset + $limit, $total_data); // Data terakhir yang ditampilkan

            // Jika total data adalah 6, maka end akan menjadi 6
            if ($total_data < $limit) {
                $end = $total_data; // Set end ke total data jika kurang dari limit
            }
        }

        // Tambahkan filter untuk NPM
        if (isset($_GET['npm'])) {
            $npm = $_GET['npm'];
            $data_transaksi = array_filter($data_transaksi, function ($data) use ($npm) {
                return $data['npm'] == $npm;
            });
        }

        // Loop melalui data transaksi yang sudah diurutkan
        foreach ($data_transaksi as $data) {
        ?>
            <tr>
                <td><?= $i++; ?></td>
                <!-- <td><?= $data['id_transaksi']; ?></td> -->
                <td><?= $data['npm']; ?></td>
                <td>
                    <?php
                    switch ($data['kode_jenis']) {
                        case '101':
                            echo 'Reward';
                            break;
                        case '102':
                            echo 'Pembelian';
                            break;
                        case '103':
                            echo 'Punishment';
                            break;
                        case '105':
                            echo 'Misi Tambahan';
                            break;
                        case '106':
                            echo 'Validasi';
                            break;
                        default:
                            echo $data['kode_jenis'];
                    }
                    ?>
                </td>
                <td><?= $data['nama_transaksi']; ?></td>
                <!-- <td><?= $data['npm']; ?></td> -->
                <td><?= $data['poin_digunakan']; ?></td>
                <td><?= date('d-m-Y', strtotime($data['tanggal_transaksi'])); ?></td>
                <td> <?php
                        switch ($data['validation']) {
                            case 'Sudah':
                                echo '<span class="badge badge-success">Sudah</span>';
                                break;
                            case 'Belum':
                                echo '<span class="badge badge-danger">Belum</span>';
                                break;
                            default:
                                echo '<span class="badge badge-secondary">Tidak Ada</span>';
                                break;
                        } ?>
                </td>
                <td>
                    <button type=" button" class="btn btn-info" data-toggle="modal" data-target="#modalDetail<?php echo $data['id_transaksi']; ?>"><i class="fas fa-eye"></i><span class="d-none d-md-inline"> Detail</span></button>
                </td>
                <?php if (in_groups(['superadmin', 'dosen'])) : ?>
                    <td>
                        <button type=" button" class="btn btn-secondary data-toggle=" modal" data-target="#modalEdit<?php echo $data['id_transaksi']; ?>"><i class="fas fa-check-circle"></i><span class="d-none d-md-inline"> Validasi</span></button>
                    </td>
                <?php endif ?>
            <?php
        }
            ?>
    </tbody>
</table>

<!-- Pagination -->
<nav class="d-flex justify-content-between align-items-center" aria-label="Page navigation">
    <!-- Menampilkan informasi jumlah data di kiri -->
    <div class="mb-3">
        Showing <?= $start; ?> to <?= $end; ?> of <?= $total_data; ?> entries
    </div>
    <!-- Menampilkan pagination di kanan -->
    <ul class="pagination mb-0">
        <!-- Tombol Previous -->
        <li class="page-item <?= ($page <= 1) ? 'disabled' : ''; ?>">
            <a class="page-link" href="?page=<?= $page - 1; ?>" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
        </li>

        <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
            <li class="page-item <?= ($i == $page) ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?= $i; ?>">
                    <?= $i; ?>
                </a>
            </li>
        <?php endfor; ?>

        <!-- Tombol Next -->
        <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : ''; ?>">
            <a class="page-link" href="?page=<?= $page + 1; ?>" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
        </li>
    </ul>
</nav>

<!-- Modal box Detail -->
<?php foreach ($data_transaksi as $data) : ?>
    <div class="modal fade" id="modalDetail<?php echo $data['id_transaksi']; ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Detail Transaksi <?= $data['npm']; ?> </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="max-height: 500px; overflow-y: auto;">
                    <div class="col-lg-13">
                        <div class="card mb-3">
                            <div class="row g-0">
                                <div class="col-md-12">
                                    <div class="card-body">
                                        <ul class="list-group list-group-flush">
                                            <!-- <h5 class="card-title"><b>Kode Transaksi :</b></h5>
                                            <li class="list-group-item">
                                                <h4><?= $data['id_transaksi']; ?></h4>
                                            </li> -->
                                            <h5 class="card-title"><b>NPM :</b></h5>
                                            <li class="list-group-item">
                                                <h4><?= $data['npm']; ?></h4>
                                            </li>
                                            <h5 class="card-title"><b>Nama Mahasiswa :</b></h5>
                                            <li class="list-group-item">
                                                <h4><?= isset($nama[$data['npm']]) ? $nama[$data['npm']] : '-'; ?></h4>
                                            </li>
                                            <h5 class="card-title"><b>Jenis Transaksi :</b></h5>
                                            <li class="list-group-item">
                                                <h4><?php
                                                    switch ($data['kode_jenis']) {
                                                        case '101':
                                                            echo 'Reward';
                                                            break;
                                                        case '102':
                                                            echo 'Pembelian';
                                                            break;
                                                        case '103':
                                                            echo 'Punishment';
                                                            break;
                                                        case '105':
                                                            echo 'Misi Tambahan';
                                                            break;
                                                        case '106':
                                                            echo 'Konsultasi';
                                                            break;
                                                        default:
                                                            echo $data['kode_jenis'];
                                                    }
                                                    ?>
                                                </h4>
                                            </li>
                                            <h5 class="card-title"><b>Nama Transaksi:</b></h5>
                                            <li class="list-group-item">
                                                <h4><?= $data['nama_transaksi']; ?></h4>
                                            </li>
                                            <h5 class="card-title"><b>Poin Digunakan :</b></h5>
                                            <li class="list-group-item">
                                                <h4><?= $data['poin_digunakan']; ?></h4>
                                            </li>
                                            <h5 class="card-title"><b>Tanggal Transaksi :</b></h5>
                                            <li class="list-group-item">
                                                <h4><?= $data['tanggal_transaksi']; ?></h4>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php endforeach; ?>

<!--Data Modal Validasi-->
<?php foreach ($data_transaksi as $data) : ?>
    <div class="modal fade" id="modalEdit<?php echo $data['id_transaksi']; ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel"><?= $title; ?> </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/Validasi/aksi/<?= $data['id_transaksi']; ?>" method="post" enctype="multipart/form-data">
                        <!-- <div class="form-group ">
                            <label for="id_transaksi" class="col-form-label">Kode Transaksi</label>
                           
                                <input type="number" class="form-control" id="id_transaksi" name="id_transaksi" value="<?php echo $data['id_transaksi'] ?>" required readonly>
                            </div> -->
                        <div class="form-group ">
                            <label for="jenis_transaksi" class="col-form-label">Jenis Transaksi</label>

                            <input type="text" class="form-control" id="jenis_transaksi" name="jenis_transaksi" value=" <?php
                                                                                                                        switch ($data['kode_jenis']) {
                                                                                                                            case '101':
                                                                                                                                echo 'Reward';
                                                                                                                                break;
                                                                                                                            case '102':
                                                                                                                                echo 'Pembelian';
                                                                                                                                break;
                                                                                                                            case '103':
                                                                                                                                echo 'Punishment';
                                                                                                                                break;
                                                                                                                            case '105':
                                                                                                                                echo 'Misi Tambahan';
                                                                                                                                break;
                                                                                                                            default:
                                                                                                                                echo $data['kode_jenis'];
                                                                                                                        }
                                                                                                                        ?>" readonly>
                        </div>
                        <div class="form-group ">
                            <label for="nama_transaksi" class="col-form-label">Nama Transaksi</label>
                            <input type="text" class="form-control" id="nama_transaksi" name="nama_transaksi" value="<?php echo $data['nama_transaksi'] ?>" readonly>
                        </div>
                        <div class="form-group ">
                            <label for="npm" class="col-form-label">NPM</label>
                            <input type="number" class="form-control" id="npm" name="npm" value="<?php echo $data['npm'] ?>" readonly>
                        </div>
                        <div class="form-group ">
                            <label for="validation" class="col-form-label">Validasi</label>
                            <select name="validation" id="validation" class="form-control" required oninvalid="this.setCustomValidity('Pilih Salah Satu')" oninput="setCustomValidity('')">
                                <option value="Sudah">Ya</option>
                                <option value="Belum">Tidak</option>
                            </select>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Validasi</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                </div>
            </div>
            </form>
        </div>
    </div>
<?php endforeach ?>