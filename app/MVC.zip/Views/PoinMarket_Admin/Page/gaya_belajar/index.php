<?= $this->extend('PoinMarket_Admin/Template/dashboard'); ?>

<?= $this->section('content'); ?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="row mb-2">
            <div class="col-sm-12 col-md-6">
                <center>
                    <h1 class="m-0 text-dark"> <?= $title; ?> </h1>
                </center>
            </div>
            <div class="col-sm-12 col-md-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                    <li class="breadcrumb-item active"><?= $title; ?></li>
                </ol>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <!-- <div class="row">
                <div class="col-md-4 offset-md-8 col-sm-12 mb-3">
                    <form action="" method="get">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Cari... ">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div> -->
            <div class="row">
                <div class="col-12">
                    <?= $this->include('PoinMarket_Admin/Card/gaya_belajar/index'); ?>
                </div>
                <div class="col-12">
                    <div class="table-responsive">
                        <!-- <= $this->include('PoinMarket_Admin/Tabel/tabel_validasi'); ?> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->endsection(); ?>