<?= $this->extend('PoinMarket_Admin/Template/dashboard'); ?>

<?= $this->section('content'); ?>

<div class="content-wrapper">
    <div class="container">
        <div class="content-header">
            <div class="row mb-2">
                <div class="col-sm-12 col-md-6">
                    <center>
                        <h1 class="m-0 text-dark"><?= $title; ?> </h1>
                    </center>
                </div><!-- /.col -->
                <div class="col-sm-12 col-md-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                        <li class="breadcrumb-item active"><?= $title; ?></li>
                    </ol>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="col-lg-8">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="/img/admin.jpg" class="img-fluid rounded-start" alt="<?= $user->username; ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <h5 class="card-title"><b>Nama :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $user->username; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>Email :</b></h5>
                                        <li class="list-group-item">
                                            <h4><?= $user->email; ?></h4>
                                        </li>
                                        <h5 class="card-title"><b>Alamat IP :</b></h5>
                                        <li class="list-group-item">
                                            <!-- <h4><?= session('user_ip'); ?></h4> <!- Menampilkan alamat IP dari sesi -->
                                            <h4><?= $_SERVER['REMOTE_ADDR']; ?></h4>
                                        </li>                                        
                                        <h5 class="card-title"><b>Token API :</b></h5>
                                        <li class="list-group-item">
                                            <input type="hidden" id="tokenInput" value="<?= $user->token; ?>">
                                            <button class="btn btn-primary btn-block" type="button" onclick="copyToken()">
                                                <i class="fas fa-key"></i> Copy Token API
                                            </button>
                                        </li>
                                        <li class="list-group-item">
                                            <!-- <span class="badge badge-<?= ($user->name == 'admin') ? 'success' : 'warning'; ?>"><?= $user->name; ?></span> -->
                                            <span class="badge badge-<?php
                                                                        if ($user->name === 'superadmin') {
                                                                            echo 'success';
                                                                        } elseif ($user->name === 'admin') {
                                                                            echo 'warning';
                                                                        } elseif ($user->name === 'dosen') {
                                                                            echo 'danger';
                                                                        } else {
                                                                            echo 'info';
                                                                        }
                                                                        ?>">
                                                <?php echo $user->name; ?>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<?= $this->endsection(); ?>

<?= $this->section('scripts'); ?>
<script>
function copyToken() {
    var tokenInput = document.getElementById('tokenInput');
    
    // Buat temporary textarea untuk menyalin teks
    var tempTextArea = document.createElement('textarea');
    tempTextArea.value = tokenInput.value;
    document.body.appendChild(tempTextArea);
    tempTextArea.select();
    document.execCommand('copy');
    document.body.removeChild(tempTextArea);
    
    // Tampilkan notifikasi menggunakan SweetAlert2
    Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: 'Token API berhasil disalin ke clipboard',
        showConfirmButton: false,
        timer: 1500
    });
}
</script>
<?= $this->endSection(); ?>