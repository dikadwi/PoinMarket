<?= $this->extend('PoinMarket_Admin/Template/dashboard'); ?>

<?= $this->section('content'); ?>

<div class="content-wrapper">

    <div class="content-header">
        <div class="row mb-2">
            <div class="col-sm-12 col-md-6">
                <center>
                    <h1 class="m-0 text-dark">Data <?= $title; ?> </h1>
                </center>
            </div><!-- /.col -->
            <div class="col-sm-12 col-md-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                    <li class="breadcrumb-item active"><?= $title; ?></li>
                </ol>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-12 col-md-6 mb-3">
                    <?php if (in_groups(['superadmin', 'dosen'])) : ?>
                        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalInput"><i class="fas fa-plus"></i><span class="d-none d-md-inline"> Input</span></button>
                    <?php endif ?>
                </div>
                <div class="col-12 col-md-6 mb-3">
                    <form action="" method="get">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Cari... ">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <?= $this->include('PoinMarket_Admin/Tabel/tabel_mahasiswa'); ?>
                    </div>
                </div>
            </div>
    </section>

</div>

<!--Data Modal Box Tambah Data-->
<div class="modal fade" id="modalTambahMahasiswa">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <h5 class="modal-title" id="staticBackdropLabel">Tambah Data Mahasiswa</h5> -->
                <h5 class="modal-title" id="staticBackdropLabel">Tambah Data Mahasiswa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/Mahasiswa/save_Mhs" method="post" enctype="multipart/form-data">
                    <div class="form-group ">
                        <label for="id" class="col-form-label"></label>
                        <input type="hidden" class="form-control" id="id" name="id" required>
                    </div>
                    <div class="form-group ">
                        <!-- <label for="nama" class="col-form-label">Nama Mahasiswa</label> -->
                        <label for="nama" class="col-form-label">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" required oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')">
                    </div>
                    <div class="form-group ">
                        <!-- <label for="npm" class="col-form-label">NPM</label> -->
                        <label for="npm" class="col-form-label">User ID/NPM</label>
                        <input type="number" class="form-control" id="npm" name="npm" required oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')">
                    </div>
                    <div class="form-group ">
                        <label for="gaya_belajar" class="col-form-label">Gaya Belajar</label>
                        <select name="gaya_belajar" id="gaya_belajar" class="form-control" required oninvalid="this.setCustomValidity('Pilih Salah Satu')" oninput="setCustomValidity('')">
                            <option value="">Pilih</option>
                            <?php foreach ($gaya_belajar as $g) : ?>
                                <option value="<?= $g['gaya_belajar'] ?>"><?= $g['id'] ?> - <?= $g['gaya_belajar'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Tambah</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            </div>
        </div>
        </form>
    </div>
</div>

<!-- Modal Input Mahasiswa -->
<div class="modal fade" id="modalInput">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-user-plus"></i> Tambah Mahasiswa Baru
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/Mahasiswa/save_Mhs" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="npm">NPM</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-hashtag"></i></span>
                            </div>
                            <input type="text" class="form-control" id="npm" name="npm" 
                                placeholder="Masukkan NPM" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="nama">Nama Mahasiswa</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" id="nama" name="nama" 
                                placeholder="Masukkan Nama Lengkap" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="gaya_belajar">Gaya Belajar</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-brain"></i></span>
                            </div>
                            <select class="form-control" id="gaya_belajar" name="gaya_belajar" required>
                                <option value="">Pilih Gaya Belajar</option>
                                <option value="Visual">Visual</option>
                                <option value="Auditori">Auditori</option>
                                <option value="Kinestetik">Kinestetik</option>
                            </select>
                        </div>
                    </div>

                    <!-- <div class="form-group">
                        <label for="point">Point Awal</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-coins"></i></span>
                            </div>
                            <input type="number" class="form-control" id="point" name="point" 
                                value="0" min="0" required>
                        </div>
                    </div> -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fas fa-times"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>




<?= $this->endsection(); ?>